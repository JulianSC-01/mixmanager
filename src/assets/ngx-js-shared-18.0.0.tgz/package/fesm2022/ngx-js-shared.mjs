import * as i3 from '@angular/common';
import { NgClass, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, Input, Injectable, ElementRef, Optional, Self, ViewChild } from '@angular/core';
import * as i2 from '@angular/forms';
import { FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import * as i2$1 from '@angular/platform-browser';

class AlertComponent {
    constructor() {
        this.alertRole = 'alert';
        this.alertType = 'alert-info';
        this.alertClass = 'alert ';
    }
    ngOnInit() {
        this.alertClass = this.alertClass + this.alertType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: AlertComponent, isStandalone: true, selector: "app-alert", inputs: { alertId: "alertId", alertRole: "alertRole", alertType: "alertType" }, ngImport: i0, template: "<div\r\n  [ngClass]=\"alertClass\"\r\n  [attr.id]=\"alertId\"\r\n  [attr.role]=\"alertRole\"\r\n  [attr.tabindex]=\"alertId ? '-1' : null\">\r\n  <p>\r\n    <ng-content/>\r\n  </p>\r\n</div>", styles: [".alert p{margin-bottom:0}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AlertComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        NgClass
                    ], selector: 'app-alert', standalone: true, template: "<div\r\n  [ngClass]=\"alertClass\"\r\n  [attr.id]=\"alertId\"\r\n  [attr.role]=\"alertRole\"\r\n  [attr.tabindex]=\"alertId ? '-1' : null\">\r\n  <p>\r\n    <ng-content/>\r\n  </p>\r\n</div>", styles: [".alert p{margin-bottom:0}\n"] }]
        }], propDecorators: { alertId: [{
                type: Input
            }], alertRole: [{
                type: Input
            }], alertType: [{
                type: Input
            }] } });

class AppFormService {
    constructor() { }
    isInvalid(control) {
        return (control &&
            control.enabled &&
            control.dirty &&
            control.invalid);
    }
    revealAllErrors(form) {
        if (form) {
            for (const field in form.controls) {
                let control = form.get(field);
                if (control instanceof FormGroup ||
                    control instanceof FormArray) {
                    this.revealAllErrors(control);
                }
                else if (control instanceof FormControl) {
                    control.markAsDirty();
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AppFormService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AppFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AppFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class FormErrorFeedbackComponent {
    constructor(formService) {
        this.formService = formService;
        this.errorFeedbackMessages = {};
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormErrorFeedbackComponent, deps: [{ token: AppFormService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FormErrorFeedbackComponent, isStandalone: true, selector: "app-form-error-feedback", inputs: { errorFeedbackControl: "errorFeedbackControl", errorFeedbackId: "errorFeedbackId", errorFeedbackMessages: "errorFeedbackMessages" }, ngImport: i0, template: "<div\r\n  class=\"text-danger\"\r\n  [attr.id]=\"errorFeedbackId\"\r\n  *ngIf=\"formService.isInvalid(errorFeedbackControl)\">\r\n  <ng-container\r\n    *ngFor=\"let error of errorFeedbackControl.errors | keyvalue\">\r\n    <small class=\"d-block\">\r\n      {{ errorFeedbackMessages[error.key] }}\r\n    </small>\r\n  </ng-container>\r\n</div>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i3.KeyValuePipe, name: "keyvalue" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormErrorFeedbackComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        CommonModule
                    ], selector: 'app-form-error-feedback', standalone: true, template: "<div\r\n  class=\"text-danger\"\r\n  [attr.id]=\"errorFeedbackId\"\r\n  *ngIf=\"formService.isInvalid(errorFeedbackControl)\">\r\n  <ng-container\r\n    *ngFor=\"let error of errorFeedbackControl.errors | keyvalue\">\r\n    <small class=\"d-block\">\r\n      {{ errorFeedbackMessages[error.key] }}\r\n    </small>\r\n  </ng-container>\r\n</div>" }]
        }], ctorParameters: () => [{ type: AppFormService }], propDecorators: { errorFeedbackControl: [{
                type: Input,
                args: [{ required: true }]
            }], errorFeedbackId: [{
                type: Input
            }], errorFeedbackMessages: [{
                type: Input
            }] } });

class FormErrorHeaderComponent {
    constructor(formService) {
        this.formService = formService;
    }
    getErrorCount(form) {
        let count = 0;
        if (form) {
            for (const field in form.controls) {
                let control = form.get(field);
                if (control instanceof FormGroup ||
                    control instanceof FormArray) {
                    count += this.getErrorCount(control);
                }
                else if (control instanceof FormControl) {
                    if (this.formService.isInvalid(control))
                        count++;
                }
            }
        }
        return count;
    }
    getErrorCountHeaderMessage() {
        let count = this.getErrorCount(this.errorHeaderFormGroup);
        if (count == 1)
            return "Please correct the error on this page.";
        if (count > 1)
            return "Please correct the " + count + " errors on this page.";
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormErrorHeaderComponent, deps: [{ token: AppFormService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FormErrorHeaderComponent, isStandalone: true, selector: "app-form-error-header", inputs: { errorHeaderFormGroup: "errorHeaderFormGroup", errorHeaderMessage: "errorHeaderMessage" }, ngImport: i0, template: "<app-alert\r\n  [alertId]=\"'errorHeader'\"\r\n  [alertRole]=\"'note'\"\r\n  [alertType]=\"'alert-danger'\"\r\n  *ngIf=\"errorHeaderMessage || getErrorCount(errorHeaderFormGroup) > 0\">\r\n  <ng-container\r\n    *ngIf=\"errorHeaderMessage;\r\n      then errorHeaderCustom else errorHeaderCount\">\r\n  </ng-container>\r\n  <ng-template #errorHeaderCustom>\r\n    {{ errorHeaderMessage }}\r\n  </ng-template>\r\n  <ng-template #errorHeaderCount>\r\n    {{ getErrorCountHeaderMessage() }}\r\n  </ng-template>\r\n</app-alert>", dependencies: [{ kind: "component", type: AlertComponent, selector: "app-alert", inputs: ["alertId", "alertRole", "alertType"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormErrorHeaderComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        AlertComponent,
                        CommonModule
                    ], selector: 'app-form-error-header', standalone: true, template: "<app-alert\r\n  [alertId]=\"'errorHeader'\"\r\n  [alertRole]=\"'note'\"\r\n  [alertType]=\"'alert-danger'\"\r\n  *ngIf=\"errorHeaderMessage || getErrorCount(errorHeaderFormGroup) > 0\">\r\n  <ng-container\r\n    *ngIf=\"errorHeaderMessage;\r\n      then errorHeaderCustom else errorHeaderCount\">\r\n  </ng-container>\r\n  <ng-template #errorHeaderCustom>\r\n    {{ errorHeaderMessage }}\r\n  </ng-template>\r\n  <ng-template #errorHeaderCount>\r\n    {{ getErrorCountHeaderMessage() }}\r\n  </ng-template>\r\n</app-alert>" }]
        }], ctorParameters: () => [{ type: AppFormService }], propDecorators: { errorHeaderFormGroup: [{
                type: Input
            }], errorHeaderMessage: [{
                type: Input
            }] } });

class FormLabelComponent {
    constructor() {
        this.labelInvisible = false;
        this.labelRequired = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FormLabelComponent, isStandalone: true, selector: "app-form-label", inputs: { labelControlId: "labelControlId", labelInvisible: "labelInvisible", labelRequired: "labelRequired" }, ngImport: i0, template: "<label\r\n  [ngClass]=\"{\r\n    'form-label' : true,\r\n    'visually-hidden' : labelInvisible}\"\r\n  [for]=\"labelControlId\">\r\n  <ng-content/>\r\n  <span\r\n    class=\"label-required\"\r\n    *ngIf=\"labelRequired\">\r\n    (required)\r\n  </span>\r\n</label>", styles: ["label{font-weight:700}.label-required{color:red}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormLabelComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        CommonModule
                    ], selector: 'app-form-label', standalone: true, template: "<label\r\n  [ngClass]=\"{\r\n    'form-label' : true,\r\n    'visually-hidden' : labelInvisible}\"\r\n  [for]=\"labelControlId\">\r\n  <ng-content/>\r\n  <span\r\n    class=\"label-required\"\r\n    *ngIf=\"labelRequired\">\r\n    (required)\r\n  </span>\r\n</label>", styles: ["label{font-weight:700}.label-required{color:red}\n"] }]
        }], ctorParameters: () => [], propDecorators: { labelControlId: [{
                type: Input
            }], labelInvisible: [{
                type: Input
            }], labelRequired: [{
                type: Input
            }] } });

class FormInputNumberComponent {
    constructor(formService, ngControl) {
        this.formService = formService;
        this.ngControl = ngControl;
        this.inputLabelInvisible = false;
        this.inputRequired = false;
        this.inputStep = 1;
        // --
        this._onChange = () => { };
        this._onTouched = () => { };
        if (ngControl) {
            ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        const ngControl = this.ngControl;
        if (ngControl && ngControl.control) {
            this.formControl = ngControl.control;
            if (this.inputMin !== undefined) {
                this.formControl.addValidators(Validators.min(this.inputMin));
                this.formControl.updateValueAndValidity();
            }
            if (this.inputMax !== undefined) {
                this.formControl.addValidators(Validators.max(this.inputMax));
                this.formControl.updateValueAndValidity();
            }
        }
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.controlDisabled = isDisabled;
    }
    writeValue(obj) {
        if (this.input) {
            this.input.nativeElement.value = obj;
        }
    }
    // --
    controlHasChanged(event) {
        const newValue = event.target.valueAsNumber;
        if (isNaN(newValue)) {
            this._onChange(null);
        }
        else {
            this._onChange(newValue);
        }
    }
    controlIsInvalid() {
        return this.formService.isInvalid(this.formControl);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormInputNumberComponent, deps: [{ token: AppFormService }, { token: i2.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FormInputNumberComponent, isStandalone: true, selector: "app-form-input-number", inputs: { inputErrorMessageId: "inputErrorMessageId", inputErrorMessages: "inputErrorMessages", inputId: "inputId", inputLabelInvisible: "inputLabelInvisible", inputLabelText: "inputLabelText", inputMin: "inputMin", inputMax: "inputMax", inputReadOnly: "inputReadOnly", inputRequired: "inputRequired", inputStep: "inputStep" }, viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true, read: ElementRef, static: true }], ngImport: i0, template: "<app-form-label\n  [labelControlId]=\"inputId\"\n  [labelInvisible]=\"inputLabelInvisible\"\n  [labelRequired]=\"inputRequired\"\n  *ngIf=\"inputLabelText\">\n  {{ inputLabelText }}\n</app-form-label>\n<input\n  #input\n  type=\"number\"\n  [attr.aria-describedby]=\"\n    controlIsInvalid() ? inputErrorMessageId : null\"\n  [attr.aria-invalid]=\"controlIsInvalid()\"\n  [attr.id]=\"inputId\"\n  [attr.min]=\"inputMin\"\n  [attr.max]=\"inputMax\"\n  [attr.readonly]=\"inputReadOnly\"\n  [attr.step]=\"inputStep\"\n  [disabled]=\"controlDisabled\"\n  [ngClass]=\"{\n    'form-control' : true,\n    'is-invalid' : controlIsInvalid(),\n    'mb-1': controlIsInvalid() && inputErrorMessages\n  }\"\n  (blur)=\"_onTouched()\"\n  (input)=\"controlHasChanged($event)\">\n<app-form-error-feedback\n  [errorFeedbackControl]=\"formControl\"\n  [errorFeedbackId]=\"inputErrorMessageId\"\n  [errorFeedbackMessages]=\"inputErrorMessages\"\n  *ngIf=\"inputErrorMessages\">\n</app-form-error-feedback>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: FormErrorFeedbackComponent, selector: "app-form-error-feedback", inputs: ["errorFeedbackControl", "errorFeedbackId", "errorFeedbackMessages"] }, { kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormInputNumberComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        CommonModule,
                        FormErrorFeedbackComponent,
                        FormLabelComponent
                    ], selector: 'app-form-input-number', standalone: true, template: "<app-form-label\n  [labelControlId]=\"inputId\"\n  [labelInvisible]=\"inputLabelInvisible\"\n  [labelRequired]=\"inputRequired\"\n  *ngIf=\"inputLabelText\">\n  {{ inputLabelText }}\n</app-form-label>\n<input\n  #input\n  type=\"number\"\n  [attr.aria-describedby]=\"\n    controlIsInvalid() ? inputErrorMessageId : null\"\n  [attr.aria-invalid]=\"controlIsInvalid()\"\n  [attr.id]=\"inputId\"\n  [attr.min]=\"inputMin\"\n  [attr.max]=\"inputMax\"\n  [attr.readonly]=\"inputReadOnly\"\n  [attr.step]=\"inputStep\"\n  [disabled]=\"controlDisabled\"\n  [ngClass]=\"{\n    'form-control' : true,\n    'is-invalid' : controlIsInvalid(),\n    'mb-1': controlIsInvalid() && inputErrorMessages\n  }\"\n  (blur)=\"_onTouched()\"\n  (input)=\"controlHasChanged($event)\">\n<app-form-error-feedback\n  [errorFeedbackControl]=\"formControl\"\n  [errorFeedbackId]=\"inputErrorMessageId\"\n  [errorFeedbackMessages]=\"inputErrorMessages\"\n  *ngIf=\"inputErrorMessages\">\n</app-form-error-feedback>" }]
        }], ctorParameters: () => [{ type: AppFormService }, { type: i2.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { inputErrorMessageId: [{
                type: Input
            }], inputErrorMessages: [{
                type: Input
            }], inputId: [{
                type: Input
            }], inputLabelInvisible: [{
                type: Input
            }], inputLabelText: [{
                type: Input
            }], inputMin: [{
                type: Input
            }], inputMax: [{
                type: Input
            }], inputReadOnly: [{
                type: Input
            }], inputRequired: [{
                type: Input
            }], inputStep: [{
                type: Input
            }], input: [{
                type: ViewChild,
                args: ['input', {
                        static: true, read: ElementRef
                    }]
            }] } });

const DEFAULT_EMPTY_OPTION_TEXT = 'Select';
class FormInputSelectComponent {
    constructor(formService, ngControl) {
        this.formService = formService;
        this.ngControl = ngControl;
        this.inputEmptyOption = true;
        this.inputEmptyOptionText = DEFAULT_EMPTY_OPTION_TEXT;
        this.inputLabelInvisible = false;
        this.inputRequired = false;
        // --
        this._onChange = () => { };
        this._onTouched = () => { };
        if (ngControl) {
            ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        const ngControl = this.ngControl;
        if (ngControl && ngControl.control) {
            this.formControl = ngControl.control;
        }
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.controlDisabled = isDisabled;
    }
    writeValue(obj) {
        if (this.input) {
            this.input.nativeElement.value = obj;
        }
    }
    // --
    controlHasChanged(event) {
        const newValue = event.target.value;
        this._onChange(newValue);
    }
    controlIsInvalid() {
        return this.formService.isInvalid(this.formControl);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormInputSelectComponent, deps: [{ token: AppFormService }, { token: i2.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FormInputSelectComponent, isStandalone: true, selector: "app-form-input-select", inputs: { inputEmptyOption: "inputEmptyOption", inputEmptyOptionText: "inputEmptyOptionText", inputErrorMessageId: "inputErrorMessageId", inputErrorMessages: "inputErrorMessages", inputId: "inputId", inputLabelInvisible: "inputLabelInvisible", inputLabelText: "inputLabelText", inputRequired: "inputRequired" }, viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true, read: ElementRef, static: true }], ngImport: i0, template: "<app-form-label\r\n  [labelControlId]=\"inputId\"\r\n  [labelInvisible]=\"inputLabelInvisible\"\r\n  [labelRequired]=\"inputRequired\"\r\n  *ngIf=\"inputLabelText\">\r\n  {{ inputLabelText }}\r\n</app-form-label>\r\n<select\r\n  #input\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId\"\r\n  [disabled]=\"controlDisabled\"\r\n  [ngClass]=\"{\r\n    'form-select' : true,\r\n    'is-invalid' : controlIsInvalid(),\r\n    'mb-1': controlIsInvalid() && inputErrorMessages\r\n  }\"\r\n  (blur)=\"_onTouched()\"\r\n  (change)=\"controlHasChanged($event)\">\r\n  <option selected value=\"\" *ngIf=\"inputEmptyOption\">\r\n    {{ inputEmptyOptionText }}\r\n  </option>\r\n  <ng-content/>\r\n</select>\r\n<app-form-error-feedback\r\n  [errorFeedbackControl]=\"formControl\"\r\n  [errorFeedbackId]=\"inputErrorMessageId\"\r\n  [errorFeedbackMessages]=\"inputErrorMessages\"\r\n  *ngIf=\"inputErrorMessages\">\r\n</app-form-error-feedback>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: FormErrorFeedbackComponent, selector: "app-form-error-feedback", inputs: ["errorFeedbackControl", "errorFeedbackId", "errorFeedbackMessages"] }, { kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormInputSelectComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        CommonModule,
                        FormErrorFeedbackComponent,
                        FormLabelComponent
                    ], selector: 'app-form-input-select', standalone: true, template: "<app-form-label\r\n  [labelControlId]=\"inputId\"\r\n  [labelInvisible]=\"inputLabelInvisible\"\r\n  [labelRequired]=\"inputRequired\"\r\n  *ngIf=\"inputLabelText\">\r\n  {{ inputLabelText }}\r\n</app-form-label>\r\n<select\r\n  #input\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId\"\r\n  [disabled]=\"controlDisabled\"\r\n  [ngClass]=\"{\r\n    'form-select' : true,\r\n    'is-invalid' : controlIsInvalid(),\r\n    'mb-1': controlIsInvalid() && inputErrorMessages\r\n  }\"\r\n  (blur)=\"_onTouched()\"\r\n  (change)=\"controlHasChanged($event)\">\r\n  <option selected value=\"\" *ngIf=\"inputEmptyOption\">\r\n    {{ inputEmptyOptionText }}\r\n  </option>\r\n  <ng-content/>\r\n</select>\r\n<app-form-error-feedback\r\n  [errorFeedbackControl]=\"formControl\"\r\n  [errorFeedbackId]=\"inputErrorMessageId\"\r\n  [errorFeedbackMessages]=\"inputErrorMessages\"\r\n  *ngIf=\"inputErrorMessages\">\r\n</app-form-error-feedback>" }]
        }], ctorParameters: () => [{ type: AppFormService }, { type: i2.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { inputEmptyOption: [{
                type: Input
            }], inputEmptyOptionText: [{
                type: Input
            }], inputErrorMessageId: [{
                type: Input
            }], inputErrorMessages: [{
                type: Input
            }], inputId: [{
                type: Input
            }], inputLabelInvisible: [{
                type: Input
            }], inputLabelText: [{
                type: Input
            }], inputRequired: [{
                type: Input
            }], input: [{
                type: ViewChild,
                args: ['input', {
                        static: true, read: ElementRef
                    }]
            }] } });

class FormInputTextComponent {
    constructor(formService, ngControl) {
        this.formService = formService;
        this.ngControl = ngControl;
        this.inputLabelInvisible = false;
        this.inputRequired = false;
        this.inputType = 'text';
        // --
        this._onChange = () => { };
        this._onTouched = () => { };
        if (ngControl) {
            ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        const ngControl = this.ngControl;
        if (ngControl && ngControl.control) {
            this.formControl = ngControl.control;
        }
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.controlDisabled = isDisabled;
    }
    writeValue(obj) {
        if (this.input) {
            this.input.nativeElement.value = obj;
        }
    }
    // --
    controlHasChanged(event) {
        const newValue = event.target.value;
        this._onChange(newValue);
    }
    controlIsInvalid() {
        return this.formService.isInvalid(this.formControl);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormInputTextComponent, deps: [{ token: AppFormService }, { token: i2.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: FormInputTextComponent, isStandalone: true, selector: "app-form-input-text", inputs: { inputErrorMessageId: "inputErrorMessageId", inputErrorMessages: "inputErrorMessages", inputId: "inputId", inputLabelInvisible: "inputLabelInvisible", inputLabelText: "inputLabelText", inputMaxLength: "inputMaxLength", inputPlaceholder: "inputPlaceholder", inputReadOnly: "inputReadOnly", inputRequired: "inputRequired", inputSize: "inputSize", inputType: "inputType" }, viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true, read: ElementRef, static: true }], ngImport: i0, template: "<app-form-label\r\n  [labelControlId]=\"inputId\"\r\n  [labelInvisible]=\"inputLabelInvisible\"\r\n  [labelRequired]=\"inputRequired\"\r\n  *ngIf=\"inputLabelText\">\r\n  {{ inputLabelText }}\r\n</app-form-label>\r\n<input\r\n  #input\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId\"\r\n  [attr.maxLength]=\"inputMaxLength\"\r\n  [attr.placeholder]=\"inputPlaceholder\"\r\n  [attr.readonly]=\"inputReadOnly\"\r\n  [attr.size]=\"inputSize\"\r\n  [attr.type]=\"inputType\"\r\n  [disabled]=\"controlDisabled\"\r\n  [ngClass]=\"{\r\n    'form-control' : true,\r\n    'is-invalid' : controlIsInvalid(),\r\n    'mb-1': controlIsInvalid() && inputErrorMessages\r\n  }\"\r\n  (blur)=\"_onTouched()\"\r\n  (input)=\"controlHasChanged($event)\">\r\n<app-form-error-feedback\r\n  [errorFeedbackControl]=\"formControl\"\r\n  [errorFeedbackId]=\"inputErrorMessageId\"\r\n  [errorFeedbackMessages]=\"inputErrorMessages\"\r\n  *ngIf=\"inputErrorMessages\">\r\n</app-form-error-feedback>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: FormErrorFeedbackComponent, selector: "app-form-error-feedback", inputs: ["errorFeedbackControl", "errorFeedbackId", "errorFeedbackMessages"] }, { kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: FormInputTextComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        CommonModule,
                        FormErrorFeedbackComponent,
                        FormLabelComponent
                    ], selector: 'app-form-input-text', standalone: true, template: "<app-form-label\r\n  [labelControlId]=\"inputId\"\r\n  [labelInvisible]=\"inputLabelInvisible\"\r\n  [labelRequired]=\"inputRequired\"\r\n  *ngIf=\"inputLabelText\">\r\n  {{ inputLabelText }}\r\n</app-form-label>\r\n<input\r\n  #input\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId\"\r\n  [attr.maxLength]=\"inputMaxLength\"\r\n  [attr.placeholder]=\"inputPlaceholder\"\r\n  [attr.readonly]=\"inputReadOnly\"\r\n  [attr.size]=\"inputSize\"\r\n  [attr.type]=\"inputType\"\r\n  [disabled]=\"controlDisabled\"\r\n  [ngClass]=\"{\r\n    'form-control' : true,\r\n    'is-invalid' : controlIsInvalid(),\r\n    'mb-1': controlIsInvalid() && inputErrorMessages\r\n  }\"\r\n  (blur)=\"_onTouched()\"\r\n  (input)=\"controlHasChanged($event)\">\r\n<app-form-error-feedback\r\n  [errorFeedbackControl]=\"formControl\"\r\n  [errorFeedbackId]=\"inputErrorMessageId\"\r\n  [errorFeedbackMessages]=\"inputErrorMessages\"\r\n  *ngIf=\"inputErrorMessages\">\r\n</app-form-error-feedback>" }]
        }], ctorParameters: () => [{ type: AppFormService }, { type: i2.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { inputErrorMessageId: [{
                type: Input
            }], inputErrorMessages: [{
                type: Input
            }], inputId: [{
                type: Input
            }], inputLabelInvisible: [{
                type: Input
            }], inputLabelText: [{
                type: Input
            }], inputMaxLength: [{
                type: Input
            }], inputPlaceholder: [{
                type: Input
            }], inputReadOnly: [{
                type: Input
            }], inputRequired: [{
                type: Input
            }], inputSize: [{
                type: Input
            }], inputType: [{
                type: Input
            }], input: [{
                type: ViewChild,
                args: ['input', {
                        static: true, read: ElementRef
                    }]
            }] } });

class PageFooterComponent {
    constructor() {
        this.buildDate = '';
        this.versionNumber = '';
    }
    ngOnInit() {
        if (this.buildDate instanceof Date) {
            this.buildDate = this.buildDate.toLocaleDateString();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: PageFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: PageFooterComponent, isStandalone: true, selector: "app-page-footer", inputs: { buildDate: "buildDate", versionNumber: "versionNumber" }, ngImport: i0, template: "<footer>\r\n  <div class=\"container\">\r\n    <div class=\"row text-end\">\r\n      <dl>\r\n        <dt>Version:</dt>\r\n        <dd>{{ versionNumber }} (built {{ buildDate }})</dd>\r\n      </dl>\r\n    </div>\r\n  </div>\r\n</footer>", styles: ["footer{border-bottom:3px solid #343a40;border-top:1px solid darkgray;background-color:#d3d3d3;margin-top:2.5rem!important}dl{margin-top:1rem!important}dt{display:inline;margin-right:.25rem!important}dd{display:inline;margin-bottom:0!important}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: PageFooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-footer', standalone: true, template: "<footer>\r\n  <div class=\"container\">\r\n    <div class=\"row text-end\">\r\n      <dl>\r\n        <dt>Version:</dt>\r\n        <dd>{{ versionNumber }} (built {{ buildDate }})</dd>\r\n      </dl>\r\n    </div>\r\n  </div>\r\n</footer>", styles: ["footer{border-bottom:3px solid #343a40;border-top:1px solid darkgray;background-color:#d3d3d3;margin-top:2.5rem!important}dl{margin-top:1rem!important}dt{display:inline;margin-right:.25rem!important}dd{display:inline;margin-bottom:0!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { buildDate: [{
                type: Input
            }], versionNumber: [{
                type: Input
            }] } });

class AppFocusService {
    constructor() { }
    focusNavbar() {
        this.focusElement('#mainNavbarLink');
    }
    focusMainHeader() {
        this.focusElement('#mainHeader');
    }
    focusErrorHeader() {
        this.focusElement('#errorHeader');
    }
    focusSuccessHeader() {
        this.focusElement('#successHeader');
    }
    focusElement(elementId) {
        setTimeout(() => {
            const element = document.querySelector(elementId);
            if (element)
                element.focus();
        }, 100);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AppFocusService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AppFocusService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: AppFocusService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class PageHeaderComponent {
    constructor(focusService, titleService) {
        this.focusService = focusService;
        this.titleService = titleService;
        this.pageTitle = '';
    }
    ngAfterViewInit() {
        this.focusService.focusMainHeader();
        if (this.header) {
            this.titleService.setTitle(this.pageTitle === '' ?
                this.header.nativeElement.innerText : this.pageTitle);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: PageHeaderComponent, deps: [{ token: AppFocusService }, { token: i2$1.Title }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: PageHeaderComponent, isStandalone: true, selector: "app-page-header", inputs: { pageTitle: "pageTitle" }, viewQueries: [{ propertyName: "header", first: true, predicate: ["header"], descendants: true }], ngImport: i0, template: "<h1\r\n  #header\r\n  id=\"mainHeader\"\r\n  tabindex=\"-1\">\r\n  <ng-content/>\r\n</h1>", styles: ["h1{border-bottom:1px solid lightgray;margin-bottom:1rem!important;outline:none;padding-bottom:.2em}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: PageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-header', standalone: true, template: "<h1\r\n  #header\r\n  id=\"mainHeader\"\r\n  tabindex=\"-1\">\r\n  <ng-content/>\r\n</h1>", styles: ["h1{border-bottom:1px solid lightgray;margin-bottom:1rem!important;outline:none;padding-bottom:.2em}\n"] }]
        }], ctorParameters: () => [{ type: AppFocusService }, { type: i2$1.Title }], propDecorators: { pageTitle: [{
                type: Input
            }], header: [{
                type: ViewChild,
                args: ['header']
            }] } });

const SPINNER_BORDER = 'spinner-border';
const SPINNER_GROW = 'spinner-grow';
class SpinnerComponent {
    constructor() {
        this.spinnerAccessibleText = 'Loading...';
        this.spinnerColor = '';
        this.spinnerSmall = false;
        this.spinnerStyle = SPINNER_BORDER;
        this.spinnerClass = '';
    }
    ngOnInit() {
        let spinnerSize = '';
        if (this.spinnerSmall) {
            switch (this.spinnerStyle) {
                case SPINNER_BORDER:
                    spinnerSize = ' spinner-border-sm';
                    break;
                case SPINNER_GROW:
                    spinnerSize = ' spinner-grow-sm';
                    break;
            }
        }
        this.spinnerClass =
            this.spinnerStyle + spinnerSize;
        if (this.spinnerColor !== '') {
            this.spinnerClass = this.spinnerClass + ' ' + this.spinnerColor;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.14", type: SpinnerComponent, isStandalone: true, selector: "app-spinner", inputs: { spinnerAccessibleText: "spinnerAccessibleText", spinnerColor: "spinnerColor", spinnerSmall: "spinnerSmall", spinnerStyle: "spinnerStyle" }, ngImport: i0, template: "<div [ngClass]=\"spinnerClass\" role=\"status\">\r\n  <span\r\n    class=\"visually-hidden\"\r\n    *ngIf=\"spinnerAccessibleText !== ''\">\r\n    {{ spinnerAccessibleText }}\r\n  </span>\r\n</div>\r\n<ng-content/>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.14", ngImport: i0, type: SpinnerComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        CommonModule
                    ], selector: 'app-spinner', standalone: true, template: "<div [ngClass]=\"spinnerClass\" role=\"status\">\r\n  <span\r\n    class=\"visually-hidden\"\r\n    *ngIf=\"spinnerAccessibleText !== ''\">\r\n    {{ spinnerAccessibleText }}\r\n  </span>\r\n</div>\r\n<ng-content/>" }]
        }], ctorParameters: () => [], propDecorators: { spinnerAccessibleText: [{
                type: Input
            }], spinnerColor: [{
                type: Input
            }], spinnerSmall: [{
                type: Input
            }], spinnerStyle: [{
                type: Input
            }] } });

/*
 * Public API Surface of ngx-js-shared
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AlertComponent, AppFocusService, AppFormService, FormErrorFeedbackComponent, FormErrorHeaderComponent, FormInputNumberComponent, FormInputSelectComponent, FormInputTextComponent, FormLabelComponent, PageFooterComponent, PageHeaderComponent, SpinnerComponent };
//# sourceMappingURL=ngx-js-shared.mjs.map
