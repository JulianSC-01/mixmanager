import { ElementRef, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, NgControl } from '@angular/forms';
import { AppFormService } from '../../services/app-form.service';
import * as i0 from "@angular/core";
export declare class FormInputSelectComponent implements ControlValueAccessor, OnInit {
    private formService;
    private ngControl;
    inputEmptyOption?: boolean;
    inputEmptyOptionText?: string;
    inputErrorMessageId?: string;
    inputErrorMessages?: {
        [key: string]: string;
    };
    inputId?: string;
    inputLabelInvisible?: boolean;
    inputLabelText?: string;
    inputRequired?: boolean;
    controlDisabled?: boolean;
    formControl: AbstractControl;
    input?: ElementRef;
    constructor(formService: AppFormService, ngControl: NgControl);
    ngOnInit(): void;
    _onChange: any;
    _onTouched: any;
    registerOnChange(fn: (val: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(obj: any): void;
    controlHasChanged(event: Event): void;
    controlIsInvalid(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormInputSelectComponent, [null, { optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormInputSelectComponent, "app-form-input-select", never, { "inputEmptyOption": { "alias": "inputEmptyOption"; "required": false; }; "inputEmptyOptionText": { "alias": "inputEmptyOptionText"; "required": false; }; "inputErrorMessageId": { "alias": "inputErrorMessageId"; "required": false; }; "inputErrorMessages": { "alias": "inputErrorMessages"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "inputLabelInvisible": { "alias": "inputLabelInvisible"; "required": false; }; "inputLabelText": { "alias": "inputLabelText"; "required": false; }; "inputRequired": { "alias": "inputRequired"; "required": false; }; }, {}, never, ["*"], true, never>;
}
