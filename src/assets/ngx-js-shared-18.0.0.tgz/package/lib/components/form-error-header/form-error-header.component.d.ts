import { FormArray, FormGroup } from '@angular/forms';
import { AppFormService } from '../../services/app-form.service';
import * as i0 from "@angular/core";
export declare class FormErrorHeaderComponent {
    private formService;
    errorHeaderFormGroup?: FormGroup<any>;
    errorHeaderMessage?: string;
    constructor(formService: AppFormService);
    getErrorCount(form?: FormGroup<any> | FormArray<any>): number;
    getErrorCountHeaderMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormErrorHeaderComponent, "app-form-error-header", never, { "errorHeaderFormGroup": { "alias": "errorHeaderFormGroup"; "required": false; }; "errorHeaderMessage": { "alias": "errorHeaderMessage"; "required": false; }; }, {}, never, never, true, never>;
}
