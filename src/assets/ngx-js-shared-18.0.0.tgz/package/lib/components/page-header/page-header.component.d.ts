import { AfterViewInit, ElementRef } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AppFocusService } from '../../services/app-focus.service';
import * as i0 from "@angular/core";
export declare class PageHeaderComponent implements AfterViewInit {
    private focusService;
    private titleService;
    pageTitle?: string;
    header?: ElementRef;
    constructor(focusService: AppFocusService, titleService: Title);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "app-page-header", never, { "pageTitle": { "alias": "pageTitle"; "required": false; }; }, {}, never, ["*"], true, never>;
}
