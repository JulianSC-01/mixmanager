import { AbstractControl } from '@angular/forms';
import { AppFormService } from '../../services/app-form.service';
import * as i0 from "@angular/core";
export declare class FormErrorFeedbackComponent {
    formService: AppFormService;
    errorFeedbackControl: AbstractControl;
    errorFeedbackId?: string;
    errorFeedbackMessages: {
        [key: string]: string;
    };
    constructor(formService: AppFormService);
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorFeedbackComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormErrorFeedbackComponent, "app-form-error-feedback", never, { "errorFeedbackControl": { "alias": "errorFeedbackControl"; "required": true; }; "errorFeedbackId": { "alias": "errorFeedbackId"; "required": false; }; "errorFeedbackMessages": { "alias": "errorFeedbackMessages"; "required": false; }; }, {}, never, never, true, never>;
}
