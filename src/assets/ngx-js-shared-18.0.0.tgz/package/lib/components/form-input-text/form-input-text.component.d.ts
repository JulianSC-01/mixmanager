import { ElementRef, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, NgControl } from '@angular/forms';
import { AppFormService } from '../../services/app-form.service';
import * as i0 from "@angular/core";
export declare class FormInputTextComponent implements ControlValueAccessor, OnInit {
    private formService;
    private ngControl;
    inputErrorMessageId?: string;
    inputErrorMessages?: {
        [key: string]: string;
    };
    inputId?: string;
    inputLabelInvisible?: boolean;
    inputLabelText?: string;
    inputMaxLength?: number;
    inputPlaceholder?: string;
    inputReadOnly?: true;
    inputRequired?: boolean;
    inputSize?: number;
    inputType?: 'text' | 'password';
    controlDisabled?: boolean;
    formControl: AbstractControl;
    input?: ElementRef;
    constructor(formService: AppFormService, ngControl: NgControl);
    ngOnInit(): void;
    _onChange: any;
    _onTouched: any;
    registerOnChange(fn: (val: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(obj: any): void;
    controlHasChanged(event: Event): void;
    controlIsInvalid(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormInputTextComponent, [null, { optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormInputTextComponent, "app-form-input-text", never, { "inputErrorMessageId": { "alias": "inputErrorMessageId"; "required": false; }; "inputErrorMessages": { "alias": "inputErrorMessages"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "inputLabelInvisible": { "alias": "inputLabelInvisible"; "required": false; }; "inputLabelText": { "alias": "inputLabelText"; "required": false; }; "inputMaxLength": { "alias": "inputMaxLength"; "required": false; }; "inputPlaceholder": { "alias": "inputPlaceholder"; "required": false; }; "inputReadOnly": { "alias": "inputReadOnly"; "required": false; }; "inputRequired": { "alias": "inputRequired"; "required": false; }; "inputSize": { "alias": "inputSize"; "required": false; }; "inputType": { "alias": "inputType"; "required": false; }; }, {}, never, never, true, never>;
}
