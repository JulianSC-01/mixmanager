import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SpinnerComponent implements OnInit {
    spinnerAccessibleText?: string;
    spinnerColor?: string;
    spinnerSmall?: boolean;
    spinnerStyle?: string;
    spinnerClass: string;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "app-spinner", never, { "spinnerAccessibleText": { "alias": "spinnerAccessibleText"; "required": false; }; "spinnerColor": { "alias": "spinnerColor"; "required": false; }; "spinnerSmall": { "alias": "spinnerSmall"; "required": false; }; "spinnerStyle": { "alias": "spinnerStyle"; "required": false; }; }, {}, never, ["*"], true, never>;
}
