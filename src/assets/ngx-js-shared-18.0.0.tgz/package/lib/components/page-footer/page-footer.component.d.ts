import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PageFooterComponent implements OnInit {
    buildDate?: string | Date;
    versionNumber?: string | number;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageFooterComponent, "app-page-footer", never, { "buildDate": { "alias": "buildDate"; "required": false; }; "versionNumber": { "alias": "versionNumber"; "required": false; }; }, {}, never, never, true, never>;
}
