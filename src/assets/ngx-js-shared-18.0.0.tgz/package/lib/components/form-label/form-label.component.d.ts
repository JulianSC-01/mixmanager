import * as i0 from "@angular/core";
export declare class FormLabelComponent {
    labelControlId?: string;
    labelInvisible?: boolean;
    labelRequired?: boolean;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<FormLabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormLabelComponent, "app-form-label", never, { "labelControlId": { "alias": "labelControlId"; "required": false; }; "labelInvisible": { "alias": "labelInvisible"; "required": false; }; "labelRequired": { "alias": "labelRequired"; "required": false; }; }, {}, never, ["*"], true, never>;
}
