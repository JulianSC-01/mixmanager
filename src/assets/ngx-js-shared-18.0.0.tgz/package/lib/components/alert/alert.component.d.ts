import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AlertComponent implements OnInit {
    alertId?: string;
    alertRole?: string;
    alertType?: string;
    alertClass: string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "app-alert", never, { "alertId": { "alias": "alertId"; "required": false; }; "alertRole": { "alias": "alertRole"; "required": false; }; "alertType": { "alias": "alertType"; "required": false; }; }, {}, never, ["*"], true, never>;
}
