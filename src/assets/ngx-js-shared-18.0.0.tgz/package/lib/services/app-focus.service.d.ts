import * as i0 from "@angular/core";
export declare class AppFocusService {
    constructor();
    focusNavbar(): void;
    focusMainHeader(): void;
    focusErrorHeader(): void;
    focusSuccessHeader(): void;
    focusElement(elementId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AppFocusService>;
}
