import { AbstractControl, FormArray, FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class AppFormService {
    constructor();
    isInvalid(control: AbstractControl): boolean;
    revealAllErrors(form: FormGroup<any> | FormArray<any>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AppFormService>;
}
