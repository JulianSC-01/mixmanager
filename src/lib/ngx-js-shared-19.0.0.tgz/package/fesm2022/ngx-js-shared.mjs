import * as i0 from '@angular/core';
import { input, computed, ChangeDetectionStrategy, Component, inject, DestroyRef, signal, Injectable, booleanAttribute, viewChild, Directive, numberAttribute, afterNextRender, effect, untracked, Pipe } from '@angular/core';
import { KeyValuePipe } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { PristineChangeEvent, StatusChangeEvent, FormGroup, FormArray, FormControl, NgControl, FormGroupDirective, NgForm } from '@angular/forms';
import { filter } from 'rxjs';
import { Title } from '@angular/platform-browser';

class AlertComponent {
    constructor() {
        this.alertId = input();
        this.alertRole = input();
        this.alertType = input('alert-info');
        this.alertClass = computed(() => `alert ${this.alertType()}`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: AlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.17", type: AlertComponent, isStandalone: true, selector: "app-alert", inputs: { alertId: { classPropertyName: "alertId", publicName: "alertId", isSignal: true, isRequired: false, transformFunction: null }, alertRole: { classPropertyName: "alertRole", publicName: "alertRole", isSignal: true, isRequired: false, transformFunction: null }, alertType: { classPropertyName: "alertType", publicName: "alertType", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div\r\n  [class]=\"alertClass()\"\r\n  [attr.id]=\"alertId()\"\r\n  [attr.role]=\"alertRole()\"\r\n  [attr.tabindex]=\"alertId() ? '-1' : null\">\r\n  <p>\r\n    <ng-content/>\r\n  </p>\r\n</div>", styles: [".alert p{margin-bottom:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: AlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-alert', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\r\n  [class]=\"alertClass()\"\r\n  [attr.id]=\"alertId()\"\r\n  [attr.role]=\"alertRole()\"\r\n  [attr.tabindex]=\"alertId() ? '-1' : null\">\r\n  <p>\r\n    <ng-content/>\r\n  </p>\r\n</div>", styles: [".alert p{margin-bottom:0}\n"] }]
        }] });

class FormHelper {
    constructor() { }
    static getErrorCountMessage(formGroup) {
        let count = this.getErrorCount(formGroup);
        if (count == 1)
            return "Please correct the error on this page.";
        if (count > 1)
            return "Please correct the " + count + " errors on this page.";
        return '';
    }
    static getErrorListener(formControl, destroyRef) {
        return formControl.events.pipe(filter(e => e instanceof PristineChangeEvent ||
            e instanceof StatusChangeEvent), takeUntilDestroyed(destroyRef));
    }
    static isInvalid(control) {
        return (control &&
            control.enabled &&
            control.dirty &&
            control.invalid);
    }
    static revealAllErrors(form) {
        if (form) {
            for (const field in form.controls) {
                let control = form.get(field);
                if (control instanceof FormGroup ||
                    control instanceof FormArray) {
                    this.revealAllErrors(control);
                }
                else if (control instanceof FormControl) {
                    control.markAsDirty();
                }
            }
        }
    }
    static getErrorCount(form) {
        let count = 0;
        if (form) {
            for (const field in form.controls) {
                let control = form.get(field);
                if (control instanceof FormGroup ||
                    control instanceof FormArray) {
                    count += this.getErrorCount(control);
                }
                else if (control instanceof FormControl) {
                    if (FormHelper.isInvalid(control))
                        count++;
                }
            }
        }
        return count;
    }
}

class FormErrorFeedbackComponent {
    constructor() {
        this.destroyRef = inject(DestroyRef);
        this.errorFeedbackControl = input.required();
        this.errorFeedbackId = input();
        this.errorFeedbackMessages = input({});
        this.formControlErrors = signal({});
        this.formControlIsInvalid = signal(false);
    }
    ngOnInit() {
        FormHelper.getErrorListener(this.errorFeedbackControl(), this.destroyRef).
            subscribe(event => {
            this.formControlErrors.set(event.source.errors);
            this.formControlIsInvalid.set(FormHelper.isInvalid(event.source));
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormErrorFeedbackComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: FormErrorFeedbackComponent, isStandalone: true, selector: "app-form-error-feedback", inputs: { errorFeedbackControl: { classPropertyName: "errorFeedbackControl", publicName: "errorFeedbackControl", isSignal: true, isRequired: true, transformFunction: null }, errorFeedbackId: { classPropertyName: "errorFeedbackId", publicName: "errorFeedbackId", isSignal: true, isRequired: false, transformFunction: null }, errorFeedbackMessages: { classPropertyName: "errorFeedbackMessages", publicName: "errorFeedbackMessages", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (formControlIsInvalid()) {\r\n  <div\r\n    class=\"text-danger\"\r\n    [attr.id]=\"errorFeedbackId()\">\r\n    @for (error of formControlErrors() | keyvalue; track error.key) {\r\n      <ng-container>\r\n        <small class=\"d-block\">\r\n          {{ errorFeedbackMessages()[error.key] }}\r\n        </small>\r\n      </ng-container>\r\n    }\r\n  </div>\r\n}", dependencies: [{ kind: "pipe", type: KeyValuePipe, name: "keyvalue" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormErrorFeedbackComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        KeyValuePipe
                    ], selector: 'app-form-error-feedback', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (formControlIsInvalid()) {\r\n  <div\r\n    class=\"text-danger\"\r\n    [attr.id]=\"errorFeedbackId()\">\r\n    @for (error of formControlErrors() | keyvalue; track error.key) {\r\n      <ng-container>\r\n        <small class=\"d-block\">\r\n          {{ errorFeedbackMessages()[error.key] }}\r\n        </small>\r\n      </ng-container>\r\n    }\r\n  </div>\r\n}" }]
        }] });

class FocusService {
    focusNavbar() {
        this.focusElement('#mainNavbarLink');
    }
    focusMainHeader() {
        this.focusElement('#mainHeader');
    }
    focusErrorHeader() {
        this.focusElement('#errorHeader');
    }
    focusSuccessHeader() {
        this.focusElement('#successHeader');
    }
    focusElement(elementId) {
        setTimeout(() => {
            const element = document.
                querySelector(elementId);
            if (element)
                element.focus();
        }, 100);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FocusService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FocusService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FocusService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class FormErrorHeaderComponent {
    constructor() {
        this.focusService = inject(FocusService);
        this.errorFormGroup = input();
        this.errorMessage = input();
        this.errorCountMessage = signal('');
    }
    clearErrors() {
        this.errorCountMessage.set('');
    }
    countErrors() {
        const formGroup = this.errorFormGroup();
        if (formGroup) {
            this.errorCountMessage.set(FormHelper.getErrorCountMessage(formGroup));
            if (this.errorCountMessage()) {
                this.focusService.focusErrorHeader();
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormErrorHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: FormErrorHeaderComponent, isStandalone: true, selector: "app-form-error-header", inputs: { errorFormGroup: { classPropertyName: "errorFormGroup", publicName: "errorFormGroup", isSignal: true, isRequired: false, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (errorMessage()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ errorMessage() }}\r\n  </app-alert>\r\n} @else if (errorCountMessage()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ errorCountMessage() }}\r\n  </app-alert>\r\n}", dependencies: [{ kind: "component", type: AlertComponent, selector: "app-alert", inputs: ["alertId", "alertRole", "alertType"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormErrorHeaderComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        AlertComponent
                    ], selector: 'app-form-error-header', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (errorMessage()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ errorMessage() }}\r\n  </app-alert>\r\n} @else if (errorCountMessage()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ errorCountMessage() }}\r\n  </app-alert>\r\n}" }]
        }] });

class FormInputBaseDirective {
    constructor() {
        this.destroyRef = inject(DestroyRef);
        this.ngControl = inject(NgControl, { self: true });
        this.inputErrorMessageId = input();
        this.inputErrorMessages = input({});
        this.inputId = input();
        this.inputLabelInvisible = input(false, { transform: booleanAttribute });
        this.inputLabelText = input();
        this.inputReadOnly = input();
        this.inputRequired = input(false, { transform: booleanAttribute });
        this.controlDisabled = signal(false);
        this.controlIsInvalid = signal(false);
        this.formControl = signal(new FormControl());
        this.input = viewChild.required('input');
        this._onChange = () => { };
        this._onTouched = () => { };
        this.ngControl.valueAccessor = this;
    }
    ngOnInit() {
        this.formControl.set(this.ngControl.control ??
            this.formControl());
        FormHelper.getErrorListener(this.formControl(), this.destroyRef).
            subscribe(event => {
            this.controlIsInvalid.set(FormHelper.isInvalid(event.source));
        });
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.controlDisabled.set(isDisabled);
    }
    writeValue(obj) {
        this.input().nativeElement.value = obj;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputBaseDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "19.2.17", type: FormInputBaseDirective, isStandalone: true, inputs: { inputErrorMessageId: { classPropertyName: "inputErrorMessageId", publicName: "inputErrorMessageId", isSignal: true, isRequired: false, transformFunction: null }, inputErrorMessages: { classPropertyName: "inputErrorMessages", publicName: "inputErrorMessages", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, inputLabelInvisible: { classPropertyName: "inputLabelInvisible", publicName: "inputLabelInvisible", isSignal: true, isRequired: false, transformFunction: null }, inputLabelText: { classPropertyName: "inputLabelText", publicName: "inputLabelText", isSignal: true, isRequired: false, transformFunction: null }, inputReadOnly: { classPropertyName: "inputReadOnly", publicName: "inputReadOnly", isSignal: true, isRequired: false, transformFunction: null }, inputRequired: { classPropertyName: "inputRequired", publicName: "inputRequired", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true, isSignal: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputBaseDirective, decorators: [{
            type: Directive
        }], ctorParameters: () => [] });

class FormLabelComponent {
    constructor() {
        this.labelControlId = input();
        this.labelInvisible = input(false, { transform: booleanAttribute });
        this.labelRequired = input(false, { transform: booleanAttribute });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: FormLabelComponent, isStandalone: true, selector: "app-form-label", inputs: { labelControlId: { classPropertyName: "labelControlId", publicName: "labelControlId", isSignal: true, isRequired: false, transformFunction: null }, labelInvisible: { classPropertyName: "labelInvisible", publicName: "labelInvisible", isSignal: true, isRequired: false, transformFunction: null }, labelRequired: { classPropertyName: "labelRequired", publicName: "labelRequired", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<label\r\n  class=\"form-label\"\r\n  [class.visually-hidden]=\"labelInvisible()\"\r\n  [for]=\"labelControlId()\">\r\n  <ng-content/>\r\n  @if (labelRequired()) {\r\n    <span class=\"label-required\">\r\n      (required)\r\n    </span>\r\n  }\r\n</label>", styles: ["label{font-weight:700}.label-required{color:red}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-form-label', changeDetection: ChangeDetectionStrategy.OnPush, template: "<label\r\n  class=\"form-label\"\r\n  [class.visually-hidden]=\"labelInvisible()\"\r\n  [for]=\"labelControlId()\">\r\n  <ng-content/>\r\n  @if (labelRequired()) {\r\n    <span class=\"label-required\">\r\n      (required)\r\n    </span>\r\n  }\r\n</label>", styles: ["label{font-weight:700}.label-required{color:red}\n"] }]
        }] });

class FormInputNumberComponent extends FormInputBaseDirective {
    constructor() {
        super(...arguments);
        this.inputMin = input(undefined, { transform: numberAttribute });
        this.inputMax = input(undefined, { transform: numberAttribute });
        this.inputStep = input(-1, { transform: numberAttribute });
    }
    controlHasChanged(event) {
        const newValue = event.target.
            valueAsNumber;
        if (isNaN(newValue)) {
            this._onChange(null);
        }
        else {
            this._onChange(newValue);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputNumberComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: FormInputNumberComponent, isStandalone: true, selector: "app-form-input-number", inputs: { inputMin: { classPropertyName: "inputMin", publicName: "inputMin", isSignal: true, isRequired: false, transformFunction: null }, inputMax: { classPropertyName: "inputMax", publicName: "inputMax", isSignal: true, isRequired: false, transformFunction: null }, inputStep: { classPropertyName: "inputStep", publicName: "inputStep", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"inputRequired()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  type=\"number\"\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.min]=\"inputMin()\"\r\n  [attr.max]=\"inputMax()\"\r\n  [attr.readonly]=\"inputReadOnly()\"\r\n  [attr.step]=\"inputStep()\"\r\n  [class.is-invalid]=\"controlIsInvalid()\"\r\n  [class.mb-1]=\"controlIsInvalid() && inputErrorMessages()\"\r\n  [disabled]=\"controlDisabled()\"\r\n  (blur)=\"_onTouched()\"\r\n  (input)=\"controlHasChanged($event)\">\r\n@if (inputErrorMessages()) {\r\n  <app-form-error-feedback\r\n    [errorFeedbackControl]=\"formControl()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\"\r\n    [errorFeedbackMessages]=\"inputErrorMessages()\">\r\n  </app-form-error-feedback>\r\n}", dependencies: [{ kind: "component", type: FormErrorFeedbackComponent, selector: "app-form-error-feedback", inputs: ["errorFeedbackControl", "errorFeedbackId", "errorFeedbackMessages"] }, { kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputNumberComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        FormErrorFeedbackComponent,
                        FormLabelComponent
                    ], selector: 'app-form-input-number', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"inputRequired()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  type=\"number\"\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.min]=\"inputMin()\"\r\n  [attr.max]=\"inputMax()\"\r\n  [attr.readonly]=\"inputReadOnly()\"\r\n  [attr.step]=\"inputStep()\"\r\n  [class.is-invalid]=\"controlIsInvalid()\"\r\n  [class.mb-1]=\"controlIsInvalid() && inputErrorMessages()\"\r\n  [disabled]=\"controlDisabled()\"\r\n  (blur)=\"_onTouched()\"\r\n  (input)=\"controlHasChanged($event)\">\r\n@if (inputErrorMessages()) {\r\n  <app-form-error-feedback\r\n    [errorFeedbackControl]=\"formControl()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\"\r\n    [errorFeedbackMessages]=\"inputErrorMessages()\">\r\n  </app-form-error-feedback>\r\n}" }]
        }] });

const DEFAULT_EMPTY_OPTION_TEXT = 'Select';
class FormInputSelectComponent extends FormInputBaseDirective {
    constructor() {
        super(...arguments);
        this.inputEmptyOption = input(true, { transform: booleanAttribute });
        this.inputEmptyOptionText = input(DEFAULT_EMPTY_OPTION_TEXT);
    }
    controlHasChanged(event) {
        const newValue = event.target.value;
        this._onChange(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputSelectComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: FormInputSelectComponent, isStandalone: true, selector: "app-form-input-select", inputs: { inputEmptyOption: { classPropertyName: "inputEmptyOption", publicName: "inputEmptyOption", isSignal: true, isRequired: false, transformFunction: null }, inputEmptyOptionText: { classPropertyName: "inputEmptyOptionText", publicName: "inputEmptyOptionText", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"inputRequired()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<select\r\n  #input\r\n  class=\"form-select\"\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [class.is-invalid]=\"controlIsInvalid()\"\r\n  [class.mb-1]=\"controlIsInvalid() && inputErrorMessages()\"\r\n  [disabled]=\"controlDisabled()\"\r\n  (blur)=\"_onTouched()\"\r\n  (change)=\"controlHasChanged($event)\">\r\n  @if (inputEmptyOption()) {\r\n    <option selected value=\"\">\r\n      {{ inputEmptyOptionText() }}\r\n    </option>\r\n  }\r\n  <ng-content/>\r\n</select>\r\n@if (inputErrorMessages()) {\r\n  <app-form-error-feedback\r\n    [errorFeedbackControl]=\"formControl()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\"\r\n    [errorFeedbackMessages]=\"inputErrorMessages()\">\r\n  </app-form-error-feedback>\r\n}", dependencies: [{ kind: "component", type: FormErrorFeedbackComponent, selector: "app-form-error-feedback", inputs: ["errorFeedbackControl", "errorFeedbackId", "errorFeedbackMessages"] }, { kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputSelectComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        FormErrorFeedbackComponent,
                        FormLabelComponent
                    ], selector: 'app-form-input-select', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"inputRequired()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<select\r\n  #input\r\n  class=\"form-select\"\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [class.is-invalid]=\"controlIsInvalid()\"\r\n  [class.mb-1]=\"controlIsInvalid() && inputErrorMessages()\"\r\n  [disabled]=\"controlDisabled()\"\r\n  (blur)=\"_onTouched()\"\r\n  (change)=\"controlHasChanged($event)\">\r\n  @if (inputEmptyOption()) {\r\n    <option selected value=\"\">\r\n      {{ inputEmptyOptionText() }}\r\n    </option>\r\n  }\r\n  <ng-content/>\r\n</select>\r\n@if (inputErrorMessages()) {\r\n  <app-form-error-feedback\r\n    [errorFeedbackControl]=\"formControl()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\"\r\n    [errorFeedbackMessages]=\"inputErrorMessages()\">\r\n  </app-form-error-feedback>\r\n}" }]
        }] });

class FormInputTextComponent extends FormInputBaseDirective {
    constructor() {
        super(...arguments);
        this.inputMaxLength = input(undefined, { transform: numberAttribute });
        this.inputPlaceholder = input();
        this.inputSize = input(undefined, { transform: numberAttribute });
        this.inputType = input('text');
    }
    controlHasChanged(event) {
        const newValue = event.target.value;
        this._onChange(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputTextComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: FormInputTextComponent, isStandalone: true, selector: "app-form-input-text", inputs: { inputMaxLength: { classPropertyName: "inputMaxLength", publicName: "inputMaxLength", isSignal: true, isRequired: false, transformFunction: null }, inputPlaceholder: { classPropertyName: "inputPlaceholder", publicName: "inputPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, inputSize: { classPropertyName: "inputSize", publicName: "inputSize", isSignal: true, isRequired: false, transformFunction: null }, inputType: { classPropertyName: "inputType", publicName: "inputType", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"inputRequired()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.maxLength]=\"inputMaxLength()\"\r\n  [attr.placeholder]=\"inputPlaceholder()\"\r\n  [attr.readonly]=\"inputReadOnly()\"\r\n  [attr.size]=\"inputSize()\"\r\n  [attr.type]=\"inputType()\"\r\n  [class.is-invalid]=\"controlIsInvalid()\"\r\n  [class.mb-1]=\"controlIsInvalid() && inputErrorMessages()\"\r\n  [disabled]=\"controlDisabled()\"\r\n  (blur)=\"_onTouched()\"\r\n  (input)=\"controlHasChanged($event)\">\r\n@if (inputErrorMessages()) {\r\n  <app-form-error-feedback\r\n    [errorFeedbackControl]=\"formControl()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\"\r\n    [errorFeedbackMessages]=\"inputErrorMessages()\">\r\n  </app-form-error-feedback>\r\n}", dependencies: [{ kind: "component", type: FormErrorFeedbackComponent, selector: "app-form-error-feedback", inputs: ["errorFeedbackControl", "errorFeedbackId", "errorFeedbackMessages"] }, { kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormInputTextComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        FormErrorFeedbackComponent,
                        FormLabelComponent
                    ], selector: 'app-form-input-text', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"inputRequired()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  [attr.aria-describedby]=\"\r\n    controlIsInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlIsInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.maxLength]=\"inputMaxLength()\"\r\n  [attr.placeholder]=\"inputPlaceholder()\"\r\n  [attr.readonly]=\"inputReadOnly()\"\r\n  [attr.size]=\"inputSize()\"\r\n  [attr.type]=\"inputType()\"\r\n  [class.is-invalid]=\"controlIsInvalid()\"\r\n  [class.mb-1]=\"controlIsInvalid() && inputErrorMessages()\"\r\n  [disabled]=\"controlDisabled()\"\r\n  (blur)=\"_onTouched()\"\r\n  (input)=\"controlHasChanged($event)\">\r\n@if (inputErrorMessages()) {\r\n  <app-form-error-feedback\r\n    [errorFeedbackControl]=\"formControl()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\"\r\n    [errorFeedbackMessages]=\"inputErrorMessages()\">\r\n  </app-form-error-feedback>\r\n}" }]
        }] });

class PageFooterComponent {
    constructor() {
        this.buildDate = input('', {
            transform: (value) => value instanceof Date ?
                value.toLocaleDateString() : value
        });
        this.versionNumber = input('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: PageFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.17", type: PageFooterComponent, isStandalone: true, selector: "app-page-footer", inputs: { buildDate: { classPropertyName: "buildDate", publicName: "buildDate", isSignal: true, isRequired: false, transformFunction: null }, versionNumber: { classPropertyName: "versionNumber", publicName: "versionNumber", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<footer>\r\n  <div class=\"container\">\r\n    <div class=\"row text-end\">\r\n      <dl>\r\n        <dt>Version:</dt>\r\n        <dd>{{ versionNumber() }} (built {{ buildDate() }})</dd>\r\n      </dl>\r\n    </div>\r\n  </div>\r\n</footer>", styles: ["footer{border-bottom:3px solid #343a40;border-top:1px solid darkgray;background-color:#d3d3d3;margin-top:2.5rem!important}dl{margin-top:1rem!important}dt{display:inline;margin-right:.25rem!important}dd{display:inline;margin-bottom:0!important}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: PageFooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-footer', changeDetection: ChangeDetectionStrategy.OnPush, template: "<footer>\r\n  <div class=\"container\">\r\n    <div class=\"row text-end\">\r\n      <dl>\r\n        <dt>Version:</dt>\r\n        <dd>{{ versionNumber() }} (built {{ buildDate() }})</dd>\r\n      </dl>\r\n    </div>\r\n  </div>\r\n</footer>", styles: ["footer{border-bottom:3px solid #343a40;border-top:1px solid darkgray;background-color:#d3d3d3;margin-top:2.5rem!important}dl{margin-top:1rem!important}dt{display:inline;margin-right:.25rem!important}dd{display:inline;margin-bottom:0!important}\n"] }]
        }] });

class PageHeaderComponent {
    constructor() {
        this.focusService = inject(FocusService);
        this.titleService = inject(Title);
        this.pageTitle = input('');
        this.header = viewChild.required('header');
        afterNextRender({
            read: () => {
                this.focusService.focusMainHeader();
            }
        });
        effect(() => {
            const header = untracked(this.header);
            this.titleService.setTitle(this.pageTitle() === '' ?
                header.nativeElement.innerText :
                this.pageTitle());
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: PageHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.17", type: PageHeaderComponent, isStandalone: true, selector: "app-page-header", inputs: { pageTitle: { classPropertyName: "pageTitle", publicName: "pageTitle", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "header", first: true, predicate: ["header"], descendants: true, isSignal: true }], ngImport: i0, template: "<h1\r\n  #header\r\n  id=\"mainHeader\"\r\n  tabindex=\"-1\">\r\n  <ng-content/>\r\n</h1>", styles: ["h1{border-bottom:1px solid lightgray;margin-bottom:1rem!important;outline:none;padding-bottom:.2em}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: PageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-header', changeDetection: ChangeDetectionStrategy.OnPush, template: "<h1\r\n  #header\r\n  id=\"mainHeader\"\r\n  tabindex=\"-1\">\r\n  <ng-content/>\r\n</h1>", styles: ["h1{border-bottom:1px solid lightgray;margin-bottom:1rem!important;outline:none;padding-bottom:.2em}\n"] }]
        }], ctorParameters: () => [] });

const SPINNER_BORDER = 'spinner-border';
const SPINNER_BORDER_SM = 'spinner-border-sm';
const SPINNER_GROW = 'spinner-grow';
const SPINNER_GROW_SM = 'spinner-grow-sm';
class SpinnerComponent {
    constructor() {
        this.spinnerAccessibleText = input('Loading...');
        this.spinnerColor = input('');
        this.spinnerSmall = input(false, { transform: booleanAttribute });
        this.spinnerStyle = input(SPINNER_BORDER);
        this.spinnerSize = computed(() => {
            if (this.spinnerSmall()) {
                switch (this.spinnerStyle()) {
                    case SPINNER_BORDER:
                        return SPINNER_BORDER_SM;
                    case SPINNER_GROW:
                        return SPINNER_GROW_SM;
                    default:
                        return SPINNER_BORDER_SM;
                }
            }
            return '';
        });
        this.spinnerClass = computed(() => {
            let spinnerClass = this.spinnerStyle();
            if (this.spinnerSize()) {
                spinnerClass =
                    `${spinnerClass} ${this.spinnerSize()}`;
            }
            if (this.spinnerColor()) {
                spinnerClass =
                    `${spinnerClass} ${this.spinnerColor()}`;
            }
            return spinnerClass;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: SpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.17", type: SpinnerComponent, isStandalone: true, selector: "app-spinner", inputs: { spinnerAccessibleText: { classPropertyName: "spinnerAccessibleText", publicName: "spinnerAccessibleText", isSignal: true, isRequired: false, transformFunction: null }, spinnerColor: { classPropertyName: "spinnerColor", publicName: "spinnerColor", isSignal: true, isRequired: false, transformFunction: null }, spinnerSmall: { classPropertyName: "spinnerSmall", publicName: "spinnerSmall", isSignal: true, isRequired: false, transformFunction: null }, spinnerStyle: { classPropertyName: "spinnerStyle", publicName: "spinnerStyle", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div [class]=\"spinnerClass()\" role=\"status\">\r\n  @if (spinnerAccessibleText()) {\r\n    <span class=\"visually-hidden\">\r\n      {{ spinnerAccessibleText() }}\r\n    </span>\r\n  }\r\n</div>\r\n<ng-content/>", changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: SpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-spinner', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div [class]=\"spinnerClass()\" role=\"status\">\r\n  @if (spinnerAccessibleText()) {\r\n    <span class=\"visually-hidden\">\r\n      {{ spinnerAccessibleText() }}\r\n    </span>\r\n  }\r\n</div>\r\n<ng-content/>" }]
        }] });

class FormA11yDirective {
    constructor() {
        this.reactiveForm = inject(FormGroupDirective, { optional: true, self: true });
        this.templateForm = inject(NgForm, { optional: true, self: true });
        this.formErrorHeader = input();
        if (this.reactiveForm) {
            this.addSubmissionListener(this.reactiveForm);
        }
        else if (this.templateForm) {
            this.addSubmissionListener(this.templateForm);
        }
    }
    addSubmissionListener(formInstance) {
        formInstance.ngSubmit.pipe(takeUntilDestroyed()).subscribe(() => {
            const formErrorHeader = this.formErrorHeader();
            if (formInstance.invalid) {
                FormHelper.revealAllErrors(formInstance.form);
            }
            if (formErrorHeader) {
                if (formInstance.valid) {
                    formErrorHeader.clearErrors();
                }
                else if (formInstance.invalid) {
                    formErrorHeader.countErrors();
                }
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormA11yDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.17", type: FormA11yDirective, isStandalone: true, selector: "form[appFormA11y]", inputs: { formErrorHeader: { classPropertyName: "formErrorHeader", publicName: "formErrorHeader", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: FormA11yDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'form[appFormA11y]'
                }]
        }], ctorParameters: () => [] });

class LeadingZeroPipe {
    transform(value, desiredLength = 2) {
        const fixedValue = Math.abs(value).toFixed();
        const fixedValueLength = fixedValue.length;
        desiredLength =
            desiredLength > 10 ? 10 : desiredLength;
        if (fixedValueLength >= desiredLength) {
            return fixedValue;
        }
        else {
            return `${'0'.repeat(desiredLength - fixedValueLength)}${fixedValue}`;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: LeadingZeroPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.17", ngImport: i0, type: LeadingZeroPipe, isStandalone: true, name: "appLeadingZero" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.17", ngImport: i0, type: LeadingZeroPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'appLeadingZero'
                }]
        }] });

/*
 * Public API Surface of ngx-js-shared
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AlertComponent, FocusService, FormA11yDirective, FormErrorFeedbackComponent, FormErrorHeaderComponent, FormInputNumberComponent, FormInputSelectComponent, FormInputTextComponent, FormLabelComponent, LeadingZeroPipe, PageFooterComponent, PageHeaderComponent, SpinnerComponent };
//# sourceMappingURL=ngx-js-shared.mjs.map
