import { DestroyRef } from "@angular/core";
import { AbstractControl, FormArray, FormGroup, PristineChangeEvent, StatusChangeEvent } from "@angular/forms";
export declare class FormHelper {
    private constructor();
    static getErrorCountMessage(formGroup: FormGroup<any>): string;
    static getErrorListener(formControl: AbstractControl, destroyRef: DestroyRef): import("rxjs").Observable<PristineChangeEvent | StatusChangeEvent>;
    static isInvalid(control: AbstractControl): boolean;
    static revealAllErrors(form: FormGroup<any> | FormArray<any>): void;
    private static getErrorCount;
}
