import { FormErrorHeaderComponent } from '../components/form-error-header/form-error-header.component';
import * as i0 from "@angular/core";
export declare class FormA11yDirective {
    private readonly reactiveForm;
    private readonly templateForm;
    readonly formErrorHeader: import("@angular/core").InputSignal<FormErrorHeaderComponent | undefined>;
    constructor();
    private addSubmissionListener;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormA11yDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormA11yDirective, "form[appFormA11y]", never, { "formErrorHeader": { "alias": "formErrorHeader"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
