import * as i0 from "@angular/core";
export declare class FocusService {
    focusNavbar(): void;
    focusMainHeader(): void;
    focusErrorHeader(): void;
    focusSuccessHeader(): void;
    focusElement(elementId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FocusService>;
}
