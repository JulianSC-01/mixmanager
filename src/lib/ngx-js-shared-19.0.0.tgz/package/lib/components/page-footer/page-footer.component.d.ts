import * as i0 from "@angular/core";
export declare class PageFooterComponent {
    readonly buildDate: import("@angular/core").InputSignalWithTransform<string, string | Date>;
    readonly versionNumber: import("@angular/core").InputSignal<string | number>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageFooterComponent, "app-page-footer", never, { "buildDate": { "alias": "buildDate"; "required": false; "isSignal": true; }; "versionNumber": { "alias": "versionNumber"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
