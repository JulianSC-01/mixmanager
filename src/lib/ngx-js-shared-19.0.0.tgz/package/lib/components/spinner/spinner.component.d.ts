import * as i0 from "@angular/core";
export declare class SpinnerComponent {
    readonly spinnerAccessibleText: import("@angular/core").InputSignal<string>;
    readonly spinnerColor: import("@angular/core").InputSignal<string>;
    readonly spinnerSmall: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly spinnerStyle: import("@angular/core").InputSignal<string>;
    readonly spinnerSize: import("@angular/core").Signal<"" | "spinner-border-sm" | "spinner-grow-sm">;
    readonly spinnerClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "app-spinner", never, { "spinnerAccessibleText": { "alias": "spinnerAccessibleText"; "required": false; "isSignal": true; }; "spinnerColor": { "alias": "spinnerColor"; "required": false; "isSignal": true; }; "spinnerSmall": { "alias": "spinnerSmall"; "required": false; "isSignal": true; }; "spinnerStyle": { "alias": "spinnerStyle"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
