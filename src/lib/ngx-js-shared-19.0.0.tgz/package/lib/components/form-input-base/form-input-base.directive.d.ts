import { ElementRef, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare abstract class FormInputBaseDirective implements ControlValueAccessor, OnInit {
    private readonly destroyRef;
    private readonly ngControl;
    readonly inputErrorMessageId: import("@angular/core").InputSignal<string | undefined>;
    readonly inputErrorMessages: import("@angular/core").InputSignal<Record<string, string>>;
    readonly inputId: import("@angular/core").InputSignal<string | undefined>;
    readonly inputLabelInvisible: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly inputLabelText: import("@angular/core").InputSignal<string | undefined>;
    readonly inputReadOnly: import("@angular/core").InputSignal<true | undefined>;
    readonly inputRequired: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly controlDisabled: import("@angular/core").WritableSignal<boolean>;
    readonly controlIsInvalid: import("@angular/core").WritableSignal<boolean>;
    readonly formControl: import("@angular/core").WritableSignal<AbstractControl<any, any>>;
    readonly input: import("@angular/core").Signal<ElementRef<any>>;
    constructor();
    ngOnInit(): void;
    _onChange: any;
    _onTouched: any;
    registerOnChange(fn: (val: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(obj: any): void;
    abstract controlHasChanged(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormInputBaseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormInputBaseDirective, never, never, { "inputErrorMessageId": { "alias": "inputErrorMessageId"; "required": false; "isSignal": true; }; "inputErrorMessages": { "alias": "inputErrorMessages"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputLabelInvisible": { "alias": "inputLabelInvisible"; "required": false; "isSignal": true; }; "inputLabelText": { "alias": "inputLabelText"; "required": false; "isSignal": true; }; "inputReadOnly": { "alias": "inputReadOnly"; "required": false; "isSignal": true; }; "inputRequired": { "alias": "inputRequired"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
