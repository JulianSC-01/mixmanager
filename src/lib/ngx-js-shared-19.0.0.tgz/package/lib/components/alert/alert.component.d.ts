import * as i0 from "@angular/core";
export declare class AlertComponent {
    readonly alertId: import("@angular/core").InputSignal<string | undefined>;
    readonly alertRole: import("@angular/core").InputSignal<string | undefined>;
    readonly alertType: import("@angular/core").InputSignal<string>;
    alertClass: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "app-alert", never, { "alertId": { "alias": "alertId"; "required": false; "isSignal": true; }; "alertRole": { "alias": "alertRole"; "required": false; "isSignal": true; }; "alertType": { "alias": "alertType"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
