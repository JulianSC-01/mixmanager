import { FormInputBaseDirective } from '../form-input-base/form-input-base.directive';
import * as i0 from "@angular/core";
export declare class FormInputNumberComponent extends FormInputBaseDirective {
    readonly inputMin: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
    readonly inputMax: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
    readonly inputStep: import("@angular/core").InputSignalWithTransform<number, unknown>;
    controlHasChanged(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormInputNumberComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormInputNumberComponent, "app-form-input-number", never, { "inputMin": { "alias": "inputMin"; "required": false; "isSignal": true; }; "inputMax": { "alias": "inputMax"; "required": false; "isSignal": true; }; "inputStep": { "alias": "inputStep"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
