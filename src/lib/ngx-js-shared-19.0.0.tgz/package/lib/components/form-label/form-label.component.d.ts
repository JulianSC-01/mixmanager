import * as i0 from "@angular/core";
export declare class FormLabelComponent {
    readonly labelControlId: import("@angular/core").InputSignal<string | undefined>;
    readonly labelInvisible: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly labelRequired: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormLabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormLabelComponent, "app-form-label", never, { "labelControlId": { "alias": "labelControlId"; "required": false; "isSignal": true; }; "labelInvisible": { "alias": "labelInvisible"; "required": false; "isSignal": true; }; "labelRequired": { "alias": "labelRequired"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
