import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PageHeaderComponent {
    private readonly focusService;
    private readonly titleService;
    readonly pageTitle: import("@angular/core").InputSignal<string>;
    readonly header: import("@angular/core").Signal<ElementRef<any>>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "app-page-header", never, { "pageTitle": { "alias": "pageTitle"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
