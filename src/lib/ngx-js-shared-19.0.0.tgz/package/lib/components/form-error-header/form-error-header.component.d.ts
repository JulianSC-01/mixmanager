import { FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormErrorHeaderComponent {
    private readonly focusService;
    readonly errorFormGroup: import("@angular/core").InputSignal<FormGroup<any> | undefined>;
    readonly errorMessage: import("@angular/core").InputSignal<string | undefined>;
    readonly errorCountMessage: import("@angular/core").WritableSignal<string>;
    clearErrors(): void;
    countErrors(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormErrorHeaderComponent, "app-form-error-header", never, { "errorFormGroup": { "alias": "errorFormGroup"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
