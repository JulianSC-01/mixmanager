import { FormInputBaseDirective } from '../form-input-base/form-input-base.directive';
import * as i0 from "@angular/core";
export declare class FormInputTextComponent extends FormInputBaseDirective {
    readonly inputMaxLength: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
    readonly inputPlaceholder: import("@angular/core").InputSignal<string | undefined>;
    readonly inputSize: import("@angular/core").InputSignalWithTransform<number | undefined, unknown>;
    readonly inputType: import("@angular/core").InputSignal<"text" | "password">;
    controlHasChanged(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormInputTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormInputTextComponent, "app-form-input-text", never, { "inputMaxLength": { "alias": "inputMaxLength"; "required": false; "isSignal": true; }; "inputPlaceholder": { "alias": "inputPlaceholder"; "required": false; "isSignal": true; }; "inputSize": { "alias": "inputSize"; "required": false; "isSignal": true; }; "inputType": { "alias": "inputType"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
