import { OnInit } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormErrorFeedbackComponent implements OnInit {
    private readonly destroyRef;
    readonly errorFeedbackControl: import("@angular/core").InputSignal<AbstractControl<any, any>>;
    readonly errorFeedbackId: import("@angular/core").InputSignal<string | undefined>;
    readonly errorFeedbackMessages: import("@angular/core").InputSignal<Record<string, string>>;
    readonly formControlErrors: import("@angular/core").WritableSignal<ValidationErrors | null>;
    readonly formControlIsInvalid: import("@angular/core").WritableSignal<boolean>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorFeedbackComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormErrorFeedbackComponent, "app-form-error-feedback", never, { "errorFeedbackControl": { "alias": "errorFeedbackControl"; "required": true; "isSignal": true; }; "errorFeedbackId": { "alias": "errorFeedbackId"; "required": false; "isSignal": true; }; "errorFeedbackMessages": { "alias": "errorFeedbackMessages"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
