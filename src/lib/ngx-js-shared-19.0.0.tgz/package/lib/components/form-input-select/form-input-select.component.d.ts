import { FormInputBaseDirective } from '../form-input-base/form-input-base.directive';
import * as i0 from "@angular/core";
export declare class FormInputSelectComponent extends FormInputBaseDirective {
    readonly inputEmptyOption: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    readonly inputEmptyOptionText: import("@angular/core").InputSignal<string>;
    controlHasChanged(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormInputSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormInputSelectComponent, "app-form-input-select", never, { "inputEmptyOption": { "alias": "inputEmptyOption"; "required": false; "isSignal": true; }; "inputEmptyOptionText": { "alias": "inputEmptyOptionText"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
