import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class LeadingZeroPipe implements PipeTransform {
    transform(value: number, desiredLength?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LeadingZeroPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LeadingZeroPipe, "appLeadingZero", true>;
}
