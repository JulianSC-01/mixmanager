/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-js-shared" />
export * from './public-api';
