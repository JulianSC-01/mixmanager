import * as _angular_core from '@angular/core';
import { Field, FieldTree, FormField, FormValueControl } from '@angular/forms/signals';

declare class FormSignalErrorFeedbackComponent<T> {
    readonly errorFormField: _angular_core.InputSignal<Field<T>>;
    readonly errorFeedbackId: _angular_core.InputSignal<string | undefined>;
    readonly fieldInvalid: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormSignalErrorFeedbackComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormSignalErrorFeedbackComponent<any>, "app-form-signal-error-feedback", never, { "errorFormField": { "alias": "errorFormField"; "required": true; "isSignal": true; }; "errorFeedbackId": { "alias": "errorFeedbackId"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FormSignalErrorHeaderComponent<T> {
    readonly errorFormRoot: _angular_core.InputSignal<FieldTree<T>>;
    readonly errorMessage: _angular_core.InputSignal<string | undefined>;
    private readonly formErrorCount;
    protected readonly formErrorCountMessage: _angular_core.Signal<string>;
    protected readonly formInvalid: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormSignalErrorHeaderComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormSignalErrorHeaderComponent<any>, "app-form-signal-error-header", never, { "errorFormRoot": { "alias": "errorFormRoot"; "required": true; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare abstract class FormSignalInputBaseDirective {
    readonly formField: FormField<any>;
    readonly inputErrorMessageId: _angular_core.InputSignal<string | undefined>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly inputLabelInvisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputLabelText: _angular_core.InputSignal<string | undefined>;
    readonly inputShowErrors: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly controlInvalid: _angular_core.Signal<boolean>;
    abstract controlChanged(event: Event): void;
    controlTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormSignalInputBaseDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FormSignalInputBaseDirective, never, never, { "inputErrorMessageId": { "alias": "inputErrorMessageId"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputLabelInvisible": { "alias": "inputLabelInvisible"; "required": false; "isSignal": true; }; "inputLabelText": { "alias": "inputLabelText"; "required": false; "isSignal": true; }; "inputShowErrors": { "alias": "inputShowErrors"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, { "touched": "touchedChange"; }, never, never, true, never>;
}

declare class FormSignalInputNumberComponent extends FormSignalInputBaseDirective implements FormValueControl<number | null> {
    readonly value: _angular_core.ModelSignal<number | null>;
    readonly min: _angular_core.InputSignal<number | undefined>;
    readonly max: _angular_core.InputSignal<number | undefined>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly inputPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly inputStep: _angular_core.InputSignalWithTransform<number, unknown>;
    controlChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormSignalInputNumberComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormSignalInputNumberComponent, "app-form-signal-input-number", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "inputPlaceholder": { "alias": "inputPlaceholder"; "required": false; "isSignal": true; }; "inputStep": { "alias": "inputStep"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

declare class FormSignalInputSelectComponent extends FormSignalInputBaseDirective implements FormValueControl<string> {
    readonly value: _angular_core.ModelSignal<string>;
    readonly inputEmptyOption: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputEmptyOptionText: _angular_core.InputSignal<string>;
    controlChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormSignalInputSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormSignalInputSelectComponent, "app-form-signal-input-select", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "inputEmptyOption": { "alias": "inputEmptyOption"; "required": false; "isSignal": true; }; "inputEmptyOptionText": { "alias": "inputEmptyOptionText"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, ["*"], true, never>;
}

declare class FormSignalInputTextComponent extends FormSignalInputBaseDirective implements FormValueControl<string> {
    readonly value: _angular_core.ModelSignal<string>;
    readonly maxLength: _angular_core.InputSignal<number | undefined>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly inputPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly inputSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputType: _angular_core.InputSignal<"text" | "password">;
    controlChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormSignalInputTextComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormSignalInputTextComponent, "app-form-signal-input-text", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "inputPlaceholder": { "alias": "inputPlaceholder"; "required": false; "isSignal": true; }; "inputSize": { "alias": "inputSize"; "required": false; "isSignal": true; }; "inputType": { "alias": "inputType"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

export { FormSignalErrorFeedbackComponent, FormSignalErrorHeaderComponent, FormSignalInputNumberComponent, FormSignalInputSelectComponent, FormSignalInputTextComponent };
