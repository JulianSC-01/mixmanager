import * as i0 from '@angular/core';
import { input, computed, ChangeDetectionStrategy, Component, inject, booleanAttribute, model, Directive, numberAttribute } from '@angular/core';
import { AlertComponent, FormLabelComponent } from 'ngx-js-shared';
import { FormField } from '@angular/forms/signals';

class FormSignalErrorFeedbackComponent {
    constructor() {
        this.errorFormField = input.required(...(ngDevMode ? [{ debugName: "errorFormField" }] : /* istanbul ignore next */ []));
        this.errorFeedbackId = input(...(ngDevMode ? [undefined, { debugName: "errorFeedbackId" }] : /* istanbul ignore next */ []));
        this.fieldInvalid = computed(() => this.errorFormField()().invalid() &&
            this.errorFormField()().touched(), ...(ngDevMode ? [{ debugName: "fieldInvalid" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalErrorFeedbackComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: FormSignalErrorFeedbackComponent, isStandalone: true, selector: "app-form-signal-error-feedback", inputs: { errorFormField: { classPropertyName: "errorFormField", publicName: "errorFormField", isSignal: true, isRequired: true, transformFunction: null }, errorFeedbackId: { classPropertyName: "errorFeedbackId", publicName: "errorFeedbackId", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (fieldInvalid()) {\r\n  <div class=\"text-danger\"\r\n    [attr.id]=\"errorFeedbackId()\">\r\n    @for (error of errorFormField()().errors(); track error.kind) {\r\n      <small class=\"d-block\">\r\n        {{ error.message }}\r\n      </small>\r\n    }\r\n  </div>\r\n}", changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalErrorFeedbackComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-form-signal-error-feedback', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (fieldInvalid()) {\r\n  <div class=\"text-danger\"\r\n    [attr.id]=\"errorFeedbackId()\">\r\n    @for (error of errorFormField()().errors(); track error.kind) {\r\n      <small class=\"d-block\">\r\n        {{ error.message }}\r\n      </small>\r\n    }\r\n  </div>\r\n}" }]
        }], propDecorators: { errorFormField: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorFormField", required: true }] }], errorFeedbackId: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorFeedbackId", required: false }] }] } });

class FormSignalErrorHeaderComponent {
    constructor() {
        this.errorFormRoot = input.required(...(ngDevMode ? [{ debugName: "errorFormRoot" }] : /* istanbul ignore next */ []));
        this.errorMessage = input(...(ngDevMode ? [undefined, { debugName: "errorMessage" }] : /* istanbul ignore next */ []));
        this.formErrorCount = computed(() => {
            let errorCount = 0;
            this.errorFormRoot()().
                errorSummary().forEach(error => {
                if (error.fieldTree().touched()) {
                    errorCount++;
                }
            });
            return errorCount;
        }, ...(ngDevMode ? [{ debugName: "formErrorCount" }] : /* istanbul ignore next */ []));
        this.formErrorCountMessage = computed(() => {
            if (this.formErrorCount() === 1) {
                return 'Please correct the error on this page.';
            }
            else if (this.formErrorCount() > 1) {
                return `Please correct the ${this.formErrorCount()} errors on this page.`;
            }
            else {
                return '';
            }
        }, ...(ngDevMode ? [{ debugName: "formErrorCountMessage" }] : /* istanbul ignore next */ []));
        this.formInvalid = computed(() => this.formErrorCount() > 0, ...(ngDevMode ? [{ debugName: "formInvalid" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalErrorHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: FormSignalErrorHeaderComponent, isStandalone: true, selector: "app-form-signal-error-header", inputs: { errorFormRoot: { classPropertyName: "errorFormRoot", publicName: "errorFormRoot", isSignal: true, isRequired: true, transformFunction: null }, errorMessage: { classPropertyName: "errorMessage", publicName: "errorMessage", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (errorMessage()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ errorMessage() }}\r\n  </app-alert>\r\n} @else if (formInvalid()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ formErrorCountMessage() }}\r\n  </app-alert>\r\n}", dependencies: [{ kind: "component", type: AlertComponent, selector: "app-alert", inputs: ["alertId", "alertRole", "alertType"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalErrorHeaderComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        AlertComponent
                    ], selector: 'app-form-signal-error-header', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (errorMessage()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ errorMessage() }}\r\n  </app-alert>\r\n} @else if (formInvalid()) {\r\n  <app-alert\r\n    alertId=\"errorHeader\"\r\n    alertRole=\"note\"\r\n    alertType=\"alert-danger\">\r\n    {{ formErrorCountMessage() }}\r\n  </app-alert>\r\n}" }]
        }], propDecorators: { errorFormRoot: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorFormRoot", required: true }] }], errorMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessage", required: false }] }] } });

class FormSignalInputBaseDirective {
    constructor() {
        this.formField = inject(FormField, { self: true });
        this.inputErrorMessageId = input(...(ngDevMode ? [undefined, { debugName: "inputErrorMessageId" }] : /* istanbul ignore next */ []));
        this.inputId = input(...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
        this.inputLabelInvisible = input(false, { ...(ngDevMode ? { debugName: "inputLabelInvisible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
        this.inputLabelText = input(...(ngDevMode ? [undefined, { debugName: "inputLabelText" }] : /* istanbul ignore next */ []));
        this.inputShowErrors = input(true, { ...(ngDevMode ? { debugName: "inputShowErrors" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.required = input(false, ...(ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []));
        this.controlInvalid = computed(() => this.invalid() && this.touched(), ...(ngDevMode ? [{ debugName: "controlInvalid" }] : /* istanbul ignore next */ []));
    }
    controlTouched() {
        this.touched.set(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputBaseDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: FormSignalInputBaseDirective, isStandalone: true, inputs: { inputErrorMessageId: { classPropertyName: "inputErrorMessageId", publicName: "inputErrorMessageId", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, inputLabelInvisible: { classPropertyName: "inputLabelInvisible", publicName: "inputLabelInvisible", isSignal: true, isRequired: false, transformFunction: null }, inputLabelText: { classPropertyName: "inputLabelText", publicName: "inputLabelText", isSignal: true, isRequired: false, transformFunction: null }, inputShowErrors: { classPropertyName: "inputShowErrors", publicName: "inputShowErrors", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { touched: "touchedChange" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputBaseDirective, decorators: [{
            type: Directive
        }], propDecorators: { inputErrorMessageId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputErrorMessageId", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], inputLabelInvisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputLabelInvisible", required: false }] }], inputLabelText: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputLabelText", required: false }] }], inputShowErrors: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputShowErrors", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }] } });

class FormSignalInputNumberComponent extends FormSignalInputBaseDirective {
    constructor() {
        super(...arguments);
        this.value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.min = input(...(ngDevMode ? [undefined, { debugName: "min" }] : /* istanbul ignore next */ []));
        this.max = input(...(ngDevMode ? [undefined, { debugName: "max" }] : /* istanbul ignore next */ []));
        this.readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
        this.inputPlaceholder = input(...(ngDevMode ? [undefined, { debugName: "inputPlaceholder" }] : /* istanbul ignore next */ []));
        this.inputStep = input(1, { ...(ngDevMode ? { debugName: "inputStep" } : /* istanbul ignore next */ {}), transform: (v) => numberAttribute(v, 1) });
    }
    controlChanged(event) {
        const newValue = event.target.
            valueAsNumber;
        if (isNaN(newValue)) {
            this.value.set(null);
        }
        else {
            this.value.set(newValue);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputNumberComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: FormSignalInputNumberComponent, isStandalone: true, selector: "app-form-signal-input-number", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, inputPlaceholder: { classPropertyName: "inputPlaceholder", publicName: "inputPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, inputStep: { classPropertyName: "inputStep", publicName: "inputStep", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, usesInheritance: true, ngImport: i0, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"required()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  type=\"number\"\r\n  [attr.aria-describedby]=\"\r\n    controlInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.step]=\"inputStep()\"\r\n  [class.is-invalid]=\"controlInvalid()\"\r\n  [class.mb-1]=\"controlInvalid() && inputShowErrors()\"\r\n  [disabled]=\"disabled()\"\r\n  [min]=\"min()\"\r\n  [max]=\"max()\"\r\n  [readonly]=\"readonly()\"\r\n  [value]=\"value()\"\r\n  (blur)=\"controlTouched()\"\r\n  (input)=\"controlChanged($event)\">\r\n@if (inputShowErrors()) {\r\n  <app-form-signal-error-feedback\r\n    [errorFormField]=\"formField.field()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\">\r\n  </app-form-signal-error-feedback>\r\n}", dependencies: [{ kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }, { kind: "component", type: FormSignalErrorFeedbackComponent, selector: "app-form-signal-error-feedback", inputs: ["errorFormField", "errorFeedbackId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputNumberComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        FormLabelComponent,
                        FormSignalErrorFeedbackComponent
                    ], selector: 'app-form-signal-input-number', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"required()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  type=\"number\"\r\n  [attr.aria-describedby]=\"\r\n    controlInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.step]=\"inputStep()\"\r\n  [class.is-invalid]=\"controlInvalid()\"\r\n  [class.mb-1]=\"controlInvalid() && inputShowErrors()\"\r\n  [disabled]=\"disabled()\"\r\n  [min]=\"min()\"\r\n  [max]=\"max()\"\r\n  [readonly]=\"readonly()\"\r\n  [value]=\"value()\"\r\n  (blur)=\"controlTouched()\"\r\n  (input)=\"controlChanged($event)\">\r\n@if (inputShowErrors()) {\r\n  <app-form-signal-error-feedback\r\n    [errorFormField]=\"formField.field()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\">\r\n  </app-form-signal-error-feedback>\r\n}" }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], inputPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputPlaceholder", required: false }] }], inputStep: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStep", required: false }] }] } });

const DEFAULT_EMPTY_OPTION_TEXT = 'Select';
class FormSignalInputSelectComponent extends FormSignalInputBaseDirective {
    constructor() {
        super(...arguments);
        this.value = model('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.inputEmptyOption = input(true, { ...(ngDevMode ? { debugName: "inputEmptyOption" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
        this.inputEmptyOptionText = input(DEFAULT_EMPTY_OPTION_TEXT, ...(ngDevMode ? [{ debugName: "inputEmptyOptionText" }] : /* istanbul ignore next */ []));
    }
    controlChanged(event) {
        const newValue = event.target.value;
        this.value.set(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputSelectComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: FormSignalInputSelectComponent, isStandalone: true, selector: "app-form-signal-input-select", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, inputEmptyOption: { classPropertyName: "inputEmptyOption", publicName: "inputEmptyOption", isSignal: true, isRequired: false, transformFunction: null }, inputEmptyOptionText: { classPropertyName: "inputEmptyOptionText", publicName: "inputEmptyOptionText", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, usesInheritance: true, ngImport: i0, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"required()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<select\r\n  #input\r\n  class=\"form-select\"\r\n  [attr.aria-describedby]=\"\r\n    controlInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [class.is-invalid]=\"controlInvalid()\"\r\n  [class.mb-1]=\"controlInvalid() && inputShowErrors()\"\r\n  [disabled]=\"disabled()\"\r\n  [value]=\"value()\"\r\n  (blur)=\"controlTouched()\"\r\n  (change)=\"controlChanged($event)\">\r\n  @if (inputEmptyOption()) {\r\n    <option selected value=\"\">\r\n      {{ inputEmptyOptionText() }}\r\n    </option>\r\n  }\r\n  <ng-content/>\r\n</select>\r\n@if (inputShowErrors()) {\r\n  <app-form-signal-error-feedback\r\n    [errorFormField]=\"formField.field()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\">\r\n  </app-form-signal-error-feedback>\r\n}", dependencies: [{ kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }, { kind: "component", type: FormSignalErrorFeedbackComponent, selector: "app-form-signal-error-feedback", inputs: ["errorFormField", "errorFeedbackId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputSelectComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        FormLabelComponent,
                        FormSignalErrorFeedbackComponent
                    ], selector: 'app-form-signal-input-select', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"required()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<select\r\n  #input\r\n  class=\"form-select\"\r\n  [attr.aria-describedby]=\"\r\n    controlInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [class.is-invalid]=\"controlInvalid()\"\r\n  [class.mb-1]=\"controlInvalid() && inputShowErrors()\"\r\n  [disabled]=\"disabled()\"\r\n  [value]=\"value()\"\r\n  (blur)=\"controlTouched()\"\r\n  (change)=\"controlChanged($event)\">\r\n  @if (inputEmptyOption()) {\r\n    <option selected value=\"\">\r\n      {{ inputEmptyOptionText() }}\r\n    </option>\r\n  }\r\n  <ng-content/>\r\n</select>\r\n@if (inputShowErrors()) {\r\n  <app-form-signal-error-feedback\r\n    [errorFormField]=\"formField.field()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\">\r\n  </app-form-signal-error-feedback>\r\n}" }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], inputEmptyOption: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputEmptyOption", required: false }] }], inputEmptyOptionText: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputEmptyOptionText", required: false }] }] } });

class FormSignalInputTextComponent extends FormSignalInputBaseDirective {
    constructor() {
        super(...arguments);
        this.value = model('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.maxLength = input(...(ngDevMode ? [undefined, { debugName: "maxLength" }] : /* istanbul ignore next */ []));
        this.readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
        this.inputPlaceholder = input(...(ngDevMode ? [undefined, { debugName: "inputPlaceholder" }] : /* istanbul ignore next */ []));
        this.inputSize = input(undefined, { ...(ngDevMode ? { debugName: "inputSize" } : /* istanbul ignore next */ {}), transform: (v) => numberAttribute(v, 50) });
        this.inputType = input('text', ...(ngDevMode ? [{ debugName: "inputType" }] : /* istanbul ignore next */ []));
    }
    controlChanged(event) {
        const newValue = event.target.value;
        this.value.set(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputTextComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: FormSignalInputTextComponent, isStandalone: true, selector: "app-form-signal-input-text", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, maxLength: { classPropertyName: "maxLength", publicName: "maxLength", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, inputPlaceholder: { classPropertyName: "inputPlaceholder", publicName: "inputPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, inputSize: { classPropertyName: "inputSize", publicName: "inputSize", isSignal: true, isRequired: false, transformFunction: null }, inputType: { classPropertyName: "inputType", publicName: "inputType", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, usesInheritance: true, ngImport: i0, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"required()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  [attr.aria-describedby]=\"\r\n    controlInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.maxLength]=\"maxLength()\"\r\n  [attr.placeholder]=\"inputPlaceholder()\"\r\n  [attr.size]=\"inputSize()\"\r\n  [attr.type]=\"inputType()\"\r\n  [class.is-invalid]=\"controlInvalid()\"\r\n  [class.mb-1]=\"controlInvalid() && inputShowErrors()\"\r\n  [disabled]=\"disabled()\"\r\n  [readonly]=\"readonly()\"\r\n  [value]=\"value()\"\r\n  (blur)=\"controlTouched()\"\r\n  (input)=\"controlChanged($event)\">\r\n@if (inputShowErrors()) {\r\n  <app-form-signal-error-feedback\r\n    [errorFormField]=\"formField.field()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\">\r\n  </app-form-signal-error-feedback>\r\n}", dependencies: [{ kind: "component", type: FormLabelComponent, selector: "app-form-label", inputs: ["labelControlId", "labelInvisible", "labelRequired"] }, { kind: "component", type: FormSignalErrorFeedbackComponent, selector: "app-form-signal-error-feedback", inputs: ["errorFormField", "errorFeedbackId"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSignalInputTextComponent, decorators: [{
            type: Component,
            args: [{ imports: [
                        FormLabelComponent,
                        FormSignalErrorFeedbackComponent
                    ], selector: 'app-form-signal-input-text', changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputLabelText()) {\r\n  <app-form-label\r\n    [labelControlId]=\"inputId()\"\r\n    [labelInvisible]=\"inputLabelInvisible()\"\r\n    [labelRequired]=\"required()\">\r\n    {{ inputLabelText() }}\r\n  </app-form-label>\r\n}\r\n<input\r\n  #input\r\n  class=\"form-control\"\r\n  [attr.aria-describedby]=\"\r\n    controlInvalid() ? inputErrorMessageId() : null\"\r\n  [attr.aria-invalid]=\"controlInvalid()\"\r\n  [attr.id]=\"inputId()\"\r\n  [attr.maxLength]=\"maxLength()\"\r\n  [attr.placeholder]=\"inputPlaceholder()\"\r\n  [attr.size]=\"inputSize()\"\r\n  [attr.type]=\"inputType()\"\r\n  [class.is-invalid]=\"controlInvalid()\"\r\n  [class.mb-1]=\"controlInvalid() && inputShowErrors()\"\r\n  [disabled]=\"disabled()\"\r\n  [readonly]=\"readonly()\"\r\n  [value]=\"value()\"\r\n  (blur)=\"controlTouched()\"\r\n  (input)=\"controlChanged($event)\">\r\n@if (inputShowErrors()) {\r\n  <app-form-signal-error-feedback\r\n    [errorFormField]=\"formField.field()\"\r\n    [errorFeedbackId]=\"inputErrorMessageId()\">\r\n  </app-form-signal-error-feedback>\r\n}" }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], maxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxLength", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], inputPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputPlaceholder", required: false }] }], inputSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputSize", required: false }] }], inputType: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputType", required: false }] }] } });

/*
 * Public API Surface of ngx-js-shared/experimental
 */

/**
 * Generated bundle index. Do not edit.
 */

export { FormSignalErrorFeedbackComponent, FormSignalErrorHeaderComponent, FormSignalInputNumberComponent, FormSignalInputSelectComponent, FormSignalInputTextComponent };
//# sourceMappingURL=ngx-js-shared-experimental.mjs.map
