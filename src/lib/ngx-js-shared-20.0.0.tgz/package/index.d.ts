import * as _angular_core from '@angular/core';
import { OnInit, ElementRef, PipeTransform } from '@angular/core';
import { AbstractControl, ValidationErrors, FormGroup, ControlValueAccessor } from '@angular/forms';

declare class AlertComponent {
    readonly alertId: _angular_core.InputSignal<string | undefined>;
    readonly alertRole: _angular_core.InputSignal<string | undefined>;
    readonly alertType: _angular_core.InputSignal<string>;
    alertClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AlertComponent, "app-alert", never, { "alertId": { "alias": "alertId"; "required": false; "isSignal": true; }; "alertRole": { "alias": "alertRole"; "required": false; "isSignal": true; }; "alertType": { "alias": "alertType"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class FormErrorFeedbackComponent implements OnInit {
    private readonly destroyRef;
    readonly errorFeedbackControl: _angular_core.InputSignal<AbstractControl<any, any, any>>;
    readonly errorFeedbackId: _angular_core.InputSignal<string | undefined>;
    readonly errorFeedbackMessages: _angular_core.InputSignal<Record<string, string>>;
    readonly formControlErrors: _angular_core.WritableSignal<ValidationErrors | null>;
    readonly formControlIsInvalid: _angular_core.WritableSignal<boolean>;
    ngOnInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormErrorFeedbackComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormErrorFeedbackComponent, "app-form-error-feedback", never, { "errorFeedbackControl": { "alias": "errorFeedbackControl"; "required": true; "isSignal": true; }; "errorFeedbackId": { "alias": "errorFeedbackId"; "required": false; "isSignal": true; }; "errorFeedbackMessages": { "alias": "errorFeedbackMessages"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FormErrorHeaderComponent {
    private readonly focusService;
    readonly errorFormGroup: _angular_core.InputSignal<FormGroup<any> | undefined>;
    readonly errorMessage: _angular_core.InputSignal<string | undefined>;
    readonly errorCountMessage: _angular_core.WritableSignal<string>;
    clearErrors(): void;
    countErrors(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormErrorHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormErrorHeaderComponent, "app-form-error-header", never, { "errorFormGroup": { "alias": "errorFormGroup"; "required": false; "isSignal": true; }; "errorMessage": { "alias": "errorMessage"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare abstract class FormInputBaseDirective implements ControlValueAccessor, OnInit {
    private readonly destroyRef;
    private readonly ngControl;
    readonly inputErrorMessageId: _angular_core.InputSignal<string | undefined>;
    readonly inputErrorMessages: _angular_core.InputSignal<Record<string, string>>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly inputLabelInvisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputLabelText: _angular_core.InputSignal<string | undefined>;
    readonly inputReadOnly: _angular_core.InputSignal<true | undefined>;
    readonly inputRequired: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly controlDisabled: _angular_core.WritableSignal<boolean>;
    readonly controlIsInvalid: _angular_core.WritableSignal<boolean>;
    readonly formControl: _angular_core.WritableSignal<AbstractControl<any, any, any>>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    constructor();
    ngOnInit(): void;
    _onChange: any;
    _onTouched: any;
    registerOnChange(fn: (val: any) => void): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(obj: any): void;
    abstract controlHasChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormInputBaseDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FormInputBaseDirective, never, never, { "inputErrorMessageId": { "alias": "inputErrorMessageId"; "required": false; "isSignal": true; }; "inputErrorMessages": { "alias": "inputErrorMessages"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputLabelInvisible": { "alias": "inputLabelInvisible"; "required": false; "isSignal": true; }; "inputLabelText": { "alias": "inputLabelText"; "required": false; "isSignal": true; }; "inputReadOnly": { "alias": "inputReadOnly"; "required": false; "isSignal": true; }; "inputRequired": { "alias": "inputRequired"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FormInputNumberComponent extends FormInputBaseDirective {
    readonly inputMin: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputMax: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputStep: _angular_core.InputSignalWithTransform<number, unknown>;
    controlHasChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormInputNumberComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormInputNumberComponent, "app-form-input-number", never, { "inputMin": { "alias": "inputMin"; "required": false; "isSignal": true; }; "inputMax": { "alias": "inputMax"; "required": false; "isSignal": true; }; "inputStep": { "alias": "inputStep"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FormInputSelectComponent extends FormInputBaseDirective {
    readonly inputEmptyOption: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inputEmptyOptionText: _angular_core.InputSignal<string>;
    controlHasChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormInputSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormInputSelectComponent, "app-form-input-select", never, { "inputEmptyOption": { "alias": "inputEmptyOption"; "required": false; "isSignal": true; }; "inputEmptyOptionText": { "alias": "inputEmptyOptionText"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class FormInputTextComponent extends FormInputBaseDirective {
    readonly inputMaxLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputPlaceholder: _angular_core.InputSignal<string | undefined>;
    readonly inputSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputType: _angular_core.InputSignal<"text" | "password">;
    controlHasChanged(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormInputTextComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormInputTextComponent, "app-form-input-text", never, { "inputMaxLength": { "alias": "inputMaxLength"; "required": false; "isSignal": true; }; "inputPlaceholder": { "alias": "inputPlaceholder"; "required": false; "isSignal": true; }; "inputSize": { "alias": "inputSize"; "required": false; "isSignal": true; }; "inputType": { "alias": "inputType"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FormLabelComponent {
    readonly labelControlId: _angular_core.InputSignal<string | undefined>;
    readonly labelInvisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly labelRequired: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormLabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormLabelComponent, "app-form-label", never, { "labelControlId": { "alias": "labelControlId"; "required": false; "isSignal": true; }; "labelInvisible": { "alias": "labelInvisible"; "required": false; "isSignal": true; }; "labelRequired": { "alias": "labelRequired"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class PageFooterComponent {
    readonly buildDate: _angular_core.InputSignalWithTransform<string, string | Date>;
    readonly versionNumber: _angular_core.InputSignal<string | number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PageFooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PageFooterComponent, "app-page-footer", never, { "buildDate": { "alias": "buildDate"; "required": false; "isSignal": true; }; "versionNumber": { "alias": "versionNumber"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class PageHeaderComponent {
    private readonly focusService;
    private readonly titleService;
    readonly pageTitle: _angular_core.InputSignal<string>;
    readonly header: _angular_core.Signal<ElementRef<any>>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PageHeaderComponent, "app-page-header", never, { "pageTitle": { "alias": "pageTitle"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class SpinnerComponent {
    readonly spinnerAccessibleText: _angular_core.InputSignal<string>;
    readonly spinnerColor: _angular_core.InputSignal<string>;
    readonly spinnerSmall: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly spinnerStyle: _angular_core.InputSignal<string>;
    readonly spinnerSize: _angular_core.Signal<"" | "spinner-border-sm" | "spinner-grow-sm">;
    readonly spinnerClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpinnerComponent, "app-spinner", never, { "spinnerAccessibleText": { "alias": "spinnerAccessibleText"; "required": false; "isSignal": true; }; "spinnerColor": { "alias": "spinnerColor"; "required": false; "isSignal": true; }; "spinnerSmall": { "alias": "spinnerSmall"; "required": false; "isSignal": true; }; "spinnerStyle": { "alias": "spinnerStyle"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class FormA11yDirective {
    private readonly reactiveForm;
    private readonly templateForm;
    readonly formErrorHeader: _angular_core.InputSignal<FormErrorHeaderComponent | undefined>;
    constructor();
    private addSubmissionListener;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormA11yDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FormA11yDirective, "form[appFormA11y]", never, { "formErrorHeader": { "alias": "formErrorHeader"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class LeadingZeroPipe implements PipeTransform {
    transform(value: number, desiredLength?: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LeadingZeroPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<LeadingZeroPipe, "appLeadingZero", true>;
}

declare class FocusService {
    focusNavbar(): void;
    focusMainHeader(): void;
    focusErrorHeader(): void;
    focusSuccessHeader(): void;
    focusElement(elementId: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FocusService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<FocusService>;
}

export { AlertComponent, FocusService, FormA11yDirective, FormErrorFeedbackComponent, FormErrorHeaderComponent, FormInputNumberComponent, FormInputSelectComponent, FormInputTextComponent, FormLabelComponent, LeadingZeroPipe, PageFooterComponent, PageHeaderComponent, SpinnerComponent };
